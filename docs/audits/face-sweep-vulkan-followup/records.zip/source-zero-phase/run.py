import subprocess,json
from pathlib import Path
root=Path('/tmp/face-sweep-app-source-7')
rows=[]
for name in ['reversed-door', 'lone-sheet', 'front-recess', 'back-recess', 'front-texture-back-override', 'ordinary-prism']:
 rc=subprocess.run(["python3",str(root/(name+".py"))],timeout=80).returncode
 rows.append(dict(case=name,returncode=rc))
(root/"execution.json").write_text(json.dumps(rows,indent=2)+"\n")
raise SystemExit(any(r["returncode"]for r in rows))
