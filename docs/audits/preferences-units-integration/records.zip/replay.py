from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time,zipfile
repo=Path('/tmp/ingetrazo-next-integration')
out=Path('/tmp/ingetrazo-units-integration')
out.mkdir(exist_ok=True)
binaries=Path('/tmp/ingetrazo-native-font-merge-target/debug/examples')
cli=binaries.parent/'ingetrazo'
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',INGETRAZO_STATE_DIR=str(out/'state'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'),XDG_CACHE_HOME=str(out/'cache'))
pin='6be29fe437a7cd992d4e079f71720821b25216b9'
assert subprocess.check_output(['git','-C',str(repo/'ingetrazo'),'rev-parse','HEAD'],text=True).strip()==pin
# Reuse exactly the reviewed CI archive/run helpers without executing other consumers.
tree=ast.parse((repo/'scripts/check-document-axes-integration.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('archive','run')],type_ignores=[]),'<CI helpers>','exec'))
started=time.monotonic()
archives={}
def fixture(name,selected,binary,mode,checker,reopen=None):
 folder=out/name
 archives[name]=archive(name,'manifest.json',selected,folder)
 run([binaries/binary,folder,mode],name+'/runtime.log')
 run([sys.executable,repo/'scripts'/checker,folder],name+'/acceptance.json')
 if reopen:run([sys.executable,repo/'scripts'/reopen,folder],name+'/reopen.log')
fixture('general-preferences',['original-preferences.json'],'context_document_lifecycle','--preferences','check-general-preferences.py')
fixture('open-recent',['original-recent.json'],'context_document_lifecycle','--recent','check-open-recent.py')
codes=['m','cm','mm','in','ft','ft-in','in-frac','ft-in-frac']
fixture('units-preferences',['original-units.json','input.igz']+[c+'.igz' for c in codes],'context_document_lifecycle','--units','check-units-preferences.py','reopen-units-preferences.py')
fixture('vcb-measurements',['original-measurements.json'],'line_command_history_fixture','--measurements','check-vcb-measurements.py')
cases=['front-z','side-x','aligned','axial-x','axial-y','nested']
fixture('dimension-preview',[c+e for c in cases for e in ('-input.igz','-original.igz')]+['preview-original.json','initial-native.json'],'dimension_anchor_acceptance_fixture','--preview','check-dimension-preview.py','reopen-dimension-preview.py')
cases=['near','outside','nested-shared','billboard','orphan']
fixture('dimension-anchor-admission',[c+e for c in cases for e in ('-input.igz','-original.igz')]+['admission-original.json','first-native-inverse-mismatch.json'],'dimension_anchor_acceptance_fixture','--admission','check-dimension-anchor-admission.py','reopen-dimension-anchor-admission.py')
replay=time.monotonic()-started
head=json.loads((out/'build.json').read_text())['runtime_commit']
paths=subprocess.check_output(['git','diff','--name-only','f1c11293',head,'--','crates','scripts','.github'],cwd=repo,text=True).splitlines()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources={p:digest(repo/p) for p in paths if (repo/p).is_file()}
for p,h in sources.items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+p],cwd=repo)).hexdigest()==h
result={'runtime_commit':head,'source_pin':pin,'source_sha256':sources,'binary_sha256':{p.name:digest(p) for p in [cli]+[binaries/n for n in ['context_document_lifecycle','line_command_history_fixture','dimension_anchor_acceptance_fixture']]},'archives':archives,'results':{n:json.loads((out/n/'acceptance.json').read_text()) for n in archives},'original_unit_reopens':json.loads((out/'units-preferences/reopen-units.json').read_text()),'replay_seconds':replay,'fresh_source_captures':0,'result':'pass'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'result':'pass','replay_seconds':replay,'results':result['results']}))
