import os,json,subprocess
from pathlib import Path
rows=[]
source=json.loads(Path('/input/solar/original.json').read_text())
for mode in ['native','portable']:
 env=dict(os.environ)
 if mode=='portable':env['INGETRAZO_DIAGNOSTIC_PORTABLE_SOURCE_DEPTH']='1'
 for name in ['solid','section','cutout']:
  row=next(c for c in source['cases']if c['name']==name);dest=Path('/out')/mode/'solar'/name;dest.mkdir(parents=True)
  cmd=['/shadow','/input/solar/'+row['igz'],str(dest),'--reference','/input/solar/original.json',name]
  with(dest/'runtime.log').open('w')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=20).returncode
  rows.append(dict(mode=mode,kind='solar',case=name,returncode=rc,command=cmd))
 for kind,program,cases in [('image','/image',['image-quadrants','image-overlap','image-opacity-below','image-opaque-behind','image-coplanar-trace']),('ghost','/ghost',['face-on','edge-on','textured-object-on'])]:
  dest=Path('/out')/mode/kind;dest.mkdir(parents=True)
  cmd=[program,'/input/'+kind,str(dest),'--source-camera']
  for name in cases:cmd+=['--case',name]
  with(dest/'runtime.log').open('w')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=20).returncode
  rows.append(dict(mode=mode,kind=kind,cases=cases,returncode=rc,command=cmd))
Path('/out/executions.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['returncode']==0 for r in rows)
