import hashlib,json,os,subprocess,time
from pathlib import Path
out=Path('/tmp/portable-changed-consumers');out.mkdir(mode=0o700)
query=lambda *a:subprocess.check_output(a,text=True).strip()
merged=query('podman','inspect','ingetrazo-publish','--format','{{.GraphDriver.Data.MergedDir}}');image=query('podman','inspect','ingetrazo-publish','--format','{{.Image}}')
(out/'nvidia.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':'libGLX_nvidia.so.0','api_version':'1.3.242'}}))
runner='''import os,json,subprocess
from pathlib import Path
rows=[]
source=json.loads(Path('/input/solar/original.json').read_text())
for mode in ['native','portable']:
 env=dict(os.environ)
 if mode=='portable':env['INGETRAZO_DIAGNOSTIC_PORTABLE_SOURCE_DEPTH']='1'
 for name in ['solid','section','cutout']:
  row=next(c for c in source['cases']if c['name']==name);dest=Path('/out')/mode/'solar'/name;dest.mkdir(parents=True)
  cmd=['/shadow','/input/solar/'+row['igz'],str(dest),'--reference','/input/solar/original.json',name]
  with(dest/'runtime.log').open('w')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=20).returncode
  rows.append(dict(mode=mode,kind='solar',case=name,returncode=rc,command=cmd))
 for kind,program,cases in [('image','/image',['image-quadrants','image-overlap','image-opacity-below','image-opaque-behind','image-coplanar-trace']),('ghost','/ghost',['face-on','edge-on','textured-object-on'])]:
  dest=Path('/out')/mode/kind;dest.mkdir(parents=True)
  cmd=[program,'/input/'+kind,str(dest),'--source-camera']
  for name in cases:cmd+=['--case',name]
  with(dest/'runtime.log').open('w')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=20).returncode
  rows.append(dict(mode=mode,kind=kind,cases=cases,returncode=rc,command=cmd))
Path('/out/executions.json').write_text(json.dumps(rows,indent=2)+'\\n')
assert all(r['returncode']==0 for r in rows)
'''
(out/'runner.py').write_text(runner)
name='portable-changed-consumers-'+str(os.getpid())
args=['podman','--cdi-spec-dir','/tmp/ingetrazo-nvidia-61571/cdi','run','--rm','--name',name,'--read-only','--network','none','--device','nvidia.com/gpu=0','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw']
for left,right in [('/usr/lib/libEGL.so.1','/usr/lib/libEGL.so.1'),('/usr/lib/libGLdispatch.so.0','/usr/lib/libGLdispatch.so.0'),(merged+'/tmp/ingetrazo-parity-python','/tmp/ingetrazo-parity-python'),(merged+'/usr/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu'),(merged+'/usr/bin','/usr/bin'),('/tmp/portable-shadow-frozen','/shadow'),('/tmp/portable-image-frozen','/image'),('/tmp/portable-ghost-frozen','/ghost'),('/tmp/portable-consumer-input','/input')]:args+=['-v',left+':'+right+':ro']
args+=['-v',str(out)+':/out:rw','-e','VK_DRIVER_FILES=/out/nvidia.json',image,'/tmp/ingetrazo-parity-python/bin/python','/out/runner.py']
start=time.monotonic();rc=124
try:
 with(out/'transport.log').open('w')as log:rc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=100).returncode
finally:
 subprocess.run(['podman','rm','--force',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
 meta={'compiled_source':'ac2b67a9ea7b8f050751d00439ae7e6868342a44','binary_sha256':{kind:hashlib.sha256(Path('/tmp/portable-'+kind+'-frozen').read_bytes()).hexdigest()for kind in ['shadow','image','ghost']},'driver_provenance':json.loads(Path('/tmp/ingetrazo-nvidia-61571/provenance.json').read_text()),'command':args,'returncode':rc,'elapsed_seconds':time.monotonic()-start}
 (out/'transport.json').write_text(json.dumps(meta,indent=2)+'\n');print(rc,meta['elapsed_seconds'])
raise SystemExit(rc)
