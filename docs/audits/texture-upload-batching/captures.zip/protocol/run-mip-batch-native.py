import subprocess,pathlib,json,os,hashlib,time,sys
q=lambda *a:subprocess.check_output(a,text=True).strip()
m=q('podman','inspect','ingetrazo-publish','--format','{{.GraphDriver.Data.MergedDir}}');im=q('podman','inspect','ingetrazo-publish','--format','{{.Image}}')
src=pathlib.Path(m+'/tmp/source-mip-batch-original');out=pathlib.Path(sys.argv[1]);assert not out.exists();out.mkdir()
(out/'icd.json').write_text('{"file_format_version":"1.0.0","ICD":{"library_path":"/usr/lib/libEGL_nvidia.so.0","api_version":"1.4.351"}}')
binary=m+os.environ.get('MIP_BINARY','/tmp/ingetrazo-skp-native-target/debug/examples/native_vulkan_texture_batch_probe');name='ingetrazo-mip-batch-'+str(os.getpid())
cmd=['podman','run','--rm','--name',name,'--read-only','--network','none','--device','nvidia.com/gpu=0','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw','-v','/usr/lib/libEGL.so.1:/usr/lib/libEGL.so.1:ro','-v','/usr/lib/libGLdispatch.so.0:/usr/lib/libGLdispatch.so.0:ro','-v',binary+':/probe:ro','-v',str(src)+':/input:ro','-v',str(out)+':/out:rw','-e','VK_DRIVER_FILES=/out/icd.json',im,'/probe','/input','/out']
start=time.monotonic();rc=124
try:
 with(out/'runtime.log').open('w')as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=60).returncode
finally:subprocess.run(['podman','rm','--force',name],capture_output=True,timeout=10)
meta={'command':cmd,'returncode':rc,'elapsed':time.monotonic()-start,'binary_sha256':hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),'source':os.environ.get('MIP_SOURCE',q('podman','exec','ingetrazo-publish','git','-C','/tmp/ingetrazo-source-mip-consumer','rev-parse','HEAD')),'reference_sha256':hashlib.sha256((src/'original.json').read_bytes()).hexdigest()};(out/'transport.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2));sys.exit(rc)
