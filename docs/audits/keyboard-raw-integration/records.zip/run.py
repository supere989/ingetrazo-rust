import ast,hashlib,json,os,subprocess,time,zipfile
from pathlib import Path
repo=Path('/tmp/ingetrazo-next-integration')
out=Path('/tmp/ingetrazo-keyboard-raw-integration')
target=Path('/tmp/ingetrazo-native-font-merge-target')
examples=target/'debug/examples'
py='/tmp/ingetrazo-parity-python/bin/python'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',QT_QPA_PLATFORM='offscreen',INGETRAZO_STATE_DIR=str(out/'state'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'),XDG_CACHE_HOME=str(out/'cache'))
pin='6be29fe437a7cd992d4e079f71720821b25216b9'
assert subprocess.check_output(['git','-C','/work/ingetrazo','rev-parse','HEAD'],text=True).strip()==pin
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
receipt={'runtime_commit':head,'source_pin':pin,'fresh_source_captures':0,'broad_local_runs':0,'stages':[],'archives':{},'binaries':{}}
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,argv,extra=None):
    log=out/(name+'.log');log.parent.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    with log.open('w') as f:p=subprocess.run(list(map(str,argv)),cwd=repo,env=dict(env,**(extra or {})),stdout=f,stderr=subprocess.STDOUT,timeout=300)
    row={'name':name,'argv':list(map(str,argv)),'seconds':time.monotonic()-start,'exit_code':p.returncode};receipt['stages'].append(row);save()
    print(json.dumps({'stage':name,'seconds':round(row['seconds'],3),'exit_code':p.returncode}),flush=True)
    assert p.returncode==0,name
# Execute the same archive admission helper as CI, without executing other consumers.
tree=ast.parse((repo/'scripts/check-document-axes-integration.py').read_text())
helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_archive')
exec(compile(ast.Module(body=[helper],type_ignores=[]),'<shared archive admission>','exec'))
def unpack(name,manifest,selected,destination,archive='source-records.zip'):
    digest=_archive(name,manifest,selected,out/destination,True,archive)
    receipt['archives'][name+'/'+manifest]=digest;save()
unpack('perspective-guide-workflows','source-manifest.json',['source.json'],'perspective')
unpack('p07-keyboard','source-manifest.json',['source.json'],'keyboard')
unpack('p07-inference','ci-source-manifest.json',['source.json','source-app.json'],'inference')
raw_manifest=json.loads((repo/'docs/audits/obj-raw-fusion/source-manifest.json').read_text())
unpack('obj-raw-fusion','source-manifest.json',[r['path'] for r in raw_manifest['entries']],'obj')
unpack('obj-raw-fusion','manifest.json',['attempts/preliminary-mesh/native-obj-fusion.json'],'obj','records.zip')
# Target handoff invalidates local workspace artifacts only; external dependencies survive.
packages=['ingetrazo-core','ingetrazo-metal','ingetrazo-tools','ingetrazo-formats','ingetrazo-render','ingetrazo-gui','ingetrazo-cli']
run('local-package-clean',['cargo','clean']+[v for n in packages for v in ('-p',n)])
names=['perspective_guide_workflows','p07_keyboard_workflows','p07_inference_workflows','context_document_lifecycle','drawing_reference_render_fixture','shift_inference_render_fixture']
run('combined-build',['cargo','build','--locked','-p','ingetrazo-gui']+[v for n in names for v in ('--example',n)])
receipt['binaries']={n:hashlib.sha256((examples/n).read_bytes()).hexdigest() for n in names};save()
run('perspective/runtime',[examples/names[0],out/'perspective/source.json',out/'perspective/native.json'])
run('perspective/check',['python3','scripts/check-perspective-guides.py',out/'perspective/source.json',out/'perspective/native.json',out/'perspective/acceptance.json'])
run('keyboard/runtime',[examples/names[1],out/'keyboard/source.json',out/'keyboard/native.json'])
run('keyboard/check',['python3','scripts/check-p07-keyboard.py',out/'keyboard/source.json',out/'keyboard/native.json',out/'keyboard/acceptance.json'])
run('inference/runtime',[examples/names[2],out/'inference/source.json',out/'inference/source-app.json',out/'inference/native.json'])
run('inference/check',['python3','scripts/check-p07-inference.py',out/'inference/source.json',out/'inference/source-app.json',out/'inference/native.json',out/'inference/acceptance.json'])
run('obj/runtime',[examples/names[3],out/'obj','--obj-raw-fusion'])
run('obj/reopen',[py,'scripts/reference-obj-raw-fusion-reopens.py',out/'obj'])
run('obj/check',['python3','scripts/check-obj-raw-fusion.py',out/'obj'])
for name,script in [('rectangle','check-rendered-drawing-reference.py'),('shift','check-rendered-shift-inference.py')]:
    (out/name).mkdir(exist_ok=True)
    run(name+'/check',['python3','scripts/'+script,'--prebuilt-dir',examples],{'INGETRAZO_RENDER_AUDIT_DIR':str(out/name)})
receipt['result']='pass';save()
