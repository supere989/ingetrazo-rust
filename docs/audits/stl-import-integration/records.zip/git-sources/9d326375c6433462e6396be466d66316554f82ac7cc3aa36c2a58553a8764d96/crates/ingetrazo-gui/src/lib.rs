// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Marco Sumari Tellez and IngeTrazo contributors.

//! # IngeTrazo GUI
//!
//! Native desktop application built on `eframe` and `egui`.
//! Includes menu bar, toolbar, status bar with VCB, inspector side tray,
//! and interactive 3D viewport canvas.

mod material_controller;
pub mod app;
#[cfg(feature="engineering-python")]
mod engineering_python;
mod ai_bridge;
mod geographic_import;
pub mod import_units;
pub mod survey_points;
pub mod survey_profile;
pub mod dem_tiles;
pub mod dem_runtime;
pub mod blender;
pub mod composer;
pub mod sheet_image;
mod sheet_image_paths;
mod composer_text_fields;
mod solar_controls;
mod bim_controller;
mod paper_raw_texture;
pub mod composer_cad;
pub mod composer_backend;
pub mod dialogs;
pub mod icons;
pub mod appearance_preferences;
pub mod menu;
mod recent_files;
pub mod preferences_editor;
pub mod statusbar;
pub mod toolbar;
mod tool_history;
pub mod tray;
pub mod viewport;
mod viewport_extent;
pub mod pointer_modifiers;

pub use app::IngeTrazoApp;

use std::path::PathBuf;

/// Launch the desktop GUI application.
pub fn run_gui(initial_file: Option<PathBuf>) -> Result<(), eframe::Error> {
    let native_options = eframe::NativeOptions {
        renderer: eframe::Renderer::Glow,
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1280.0, 800.0])
            .with_min_inner_size([640.0, 480.0])
            .with_title("IngeTrazo 0.3.15 (Rust native)"),
        ..Default::default()
    };

    eframe::run_native(
        "IngeTrazo",
        native_options,
        Box::new(move |cc| {
            use eframe::glow::HasContext;
            if let Some(gl) = &cc.gl {
                // This identifies the actual native renderer used at startup.
                unsafe {
                    log::info!("Graphics backend: OpenGL; vendor={}; renderer={}; version={}",
                        gl.get_parameter_string(eframe::glow::VENDOR),
                        gl.get_parameter_string(eframe::glow::RENDERER),
                        gl.get_parameter_string(eframe::glow::VERSION));
                }
            }
            let mut app=IngeTrazoApp::new();
            app.set_geotiff_device_ceiling(cc.gl.as_ref().and_then(|gl| {
                let side = unsafe { gl.get_parameter_i32(eframe::glow::MAX_TEXTURE_SIZE) };
                usize::try_from(side).ok().filter(|&value| value > 0)
            }));
            app.system_clipboard=arboard::Clipboard::new().ok();
            app.attach_session_store(crate::session_state::SessionStore::user_default());
            if let Some(path)=initial_file {app.open_document(&path);}
            Ok(Box::new(app))
        }),
    )

}

#[cfg(test)]
mod tests {
    use super::*;
    use glam::DVec3;
    use ingetrazo_core::camera::StandardView;
    use ingetrazo_core::scene::SelectionItem;
    use ingetrazo_render::style::VisualStyle;
    use ingetrazo_tools::base::ToolType;

    #[test]
    fn test_app_initialization() {
        let app = IngeTrazoApp::new();
        assert_eq!(app.active_tool_type, ToolType::Select);
        assert!(app.show_toolbar);
        assert!(app.show_tray);
        assert_eq!(app.style.visual_style, VisualStyle::ShadedWithTextures);
    }

    #[test]
    fn test_app_tool_switching() {
        let mut app = IngeTrazoApp::new();
        app.set_tool(ToolType::Line);
        assert_eq!(app.active_tool_type, ToolType::Line);
        assert_eq!(app.active_tool.name(), "Line");
        assert_eq!(app.active_tool.vcb_label(), "Length");

        app.set_tool(ToolType::Rectangle);
        assert_eq!(app.active_tool_type, ToolType::Rectangle);
        assert_eq!(app.active_tool.vcb_label(), "Dimensions");
    }

    #[test]
    fn test_app_undo_redo() {
        let mut app = IngeTrazoApp::new();
        assert_eq!(app.scene.mesh.vertices.len(), 0);

        app.save_undo_state();
        app.scene.mesh.add_vertex(DVec3::new(1.0, 2.0, 3.0));
        assert_eq!(app.scene.mesh.vertices.len(), 1);

        app.undo();
        assert_eq!(app.scene.mesh.vertices.len(), 0);

        app.redo();
        assert_eq!(app.scene.mesh.vertices.len(), 1);
    }

    #[test]
    fn test_app_delete_and_select_all() {
        let mut app = IngeTrazoApp::new();
        let v0 = app.scene.mesh.add_vertex(DVec3::new(0.0, 0.0, 0.0));
        let v1 = app.scene.mesh.add_vertex(DVec3::new(1.0, 0.0, 0.0));
        let v2 = app.scene.mesh.add_vertex(DVec3::new(1.0, 1.0, 0.0));
        let f = app.scene.mesh.add_face(vec![v0, v1, v2], vec![]).unwrap();

        app.select_all();
        assert!(app.scene.is_selected(&SelectionItem::Face(f)));

        app.delete_selection();
        assert_eq!(app.scene.mesh.faces.len(), 0);
    }

    #[test]
    fn test_app_camera_presets() {
        let mut app = IngeTrazoApp::new();
        app.camera.set_standard_view(StandardView::Top);
        assert!(app.camera.pitch > 1.5); // close to 90 degrees
    }
}

pub mod component_edit;

pub mod session_state;

pub mod document_session;

pub mod clipboard;

pub mod saved_view_actions;

pub mod outliner;

mod geometry_actions;
pub mod dimension_actions;

pub mod section_actions;

#[cfg(any(target_os="linux",target_os="windows"))]
pub mod native_vulkan;

pub mod gpu_memory;
pub mod composer_compute;

#[cfg(target_os="macos")]
pub mod native_metal;
mod history_views;
mod history_visibility;
mod history_layers;
mod document_presentation;

mod history_terrain;

mod image_plane_actions;

pub mod image_outlines;
pub mod image_outline_chunks;
pub mod image_outline_arena;
pub mod navigation;
pub mod navigation_ray;

pub mod composer_border;
mod history_edges;

mod annotation_overlay_geometry;
mod annotation_plan;
mod annotation_pick;
pub mod annotation_editor;
pub mod dimension_style;

mod bim_history;

pub mod scale_overlay;

pub mod text3d;

mod box_selection;
mod cursor_navigation;
mod annotation_delete;
mod zoom_extents;

pub use annotation_plan::annotation_plan_for_probe;

mod vcb_input;

mod composer_symbols;
mod composer_view_captions;
mod composer_legend;
mod composer_annotations;
mod composer_frame_projection;
pub mod frame_annotation_sync_consumer;

mod composer_picture;

mod dwg_import;
mod geotiff_import;
mod stl_import;
