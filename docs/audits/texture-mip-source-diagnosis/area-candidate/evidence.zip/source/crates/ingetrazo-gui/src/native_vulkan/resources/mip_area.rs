//! Reused cold GPU area-mip pipeline. No CPU image generation or extra submission.
//! The candidate remains explicit in diagnostics until source byte parity passes.
use super::super::{VulkanContext,lifetime::Lifetime};
use ash::{vk,Device};
use std::sync::Arc;
pub(super) struct Pipeline {device:Device,lifetime:Arc<Lifetime>,layout:vk::DescriptorSetLayout,pipeline_layout:vk::PipelineLayout,pipeline:vk::Pipeline}
impl Pipeline {
 pub(super) fn new(context:&VulkanContext)->Result<Self,String>{
  let device=context.device.clone();let mut owner=Self{device,lifetime:context.lifetime.clone(),layout:vk::DescriptorSetLayout::null(),pipeline_layout:vk::PipelineLayout::null(),pipeline:vk::Pipeline::null()};
  let bindings=[0,1].map(|binding|vk::DescriptorSetLayoutBinding::default().binding(binding).descriptor_type(vk::DescriptorType::STORAGE_IMAGE).descriptor_count(1).stage_flags(vk::ShaderStageFlags::COMPUTE));
  unsafe{
   owner.layout=owner.device.create_descriptor_set_layout(&vk::DescriptorSetLayoutCreateInfo::default().bindings(&bindings),None).map_err(|e|e.to_string())?;
   owner.pipeline_layout=owner.device.create_pipeline_layout(&vk::PipelineLayoutCreateInfo::default().set_layouts(&[owner.layout]),None).map_err(|e|e.to_string())?;
   let words=ash::util::read_spv(&mut std::io::Cursor::new(include_bytes!("../shaders/mip_area.comp.spv"))).map_err(|e|e.to_string())?;
   let module=owner.device.create_shader_module(&vk::ShaderModuleCreateInfo::default().code(&words),None).map_err(|e|e.to_string())?;
   let result=owner.device.create_compute_pipelines(vk::PipelineCache::null(),&[vk::ComputePipelineCreateInfo::default().stage(vk::PipelineShaderStageCreateInfo::default().stage(vk::ShaderStageFlags::COMPUTE).module(module).name(c"main")).layout(owner.pipeline_layout)],None);
   owner.device.destroy_shader_module(module,None);
   owner.pipeline=match result{Ok(p)=>p[0],Err((partial,e))=>{for p in partial{owner.device.destroy_pipeline(p,None);}return Err(e.to_string());}};
  }
  Ok(owner)
 }
 pub(super) fn prepare(&self,image:vk::Image,layout:&ingetrazo_render::texture_layout::Layout)->Result<Job,String>{
  self.lifetime.check()?;
  let levels=layout.mips.len();let odd:Vec<_>=(1..levels).filter(|&i|needs_area(layout.mips[i-1].width,layout.mips[i-1].height)).collect();
  let mut job=Job{device:self.device.clone(),lifetime:self.lifetime.clone(),pool:vk::DescriptorPool::null(),views:Vec::new(),sets:vec![vk::DescriptorSet::null();levels]};
  if odd.is_empty(){return Ok(job);}
  // Texture layout limits levels to u32 extents, so at most32 mip records.
  if levels>32{return Err("Area mip level extent exceeds32".into());}
  job.views.try_reserve_exact(odd.len()*2).map_err(|_|"Area mip view metadata refused")?;
  unsafe{
   job.pool=self.device.create_descriptor_pool(&vk::DescriptorPoolCreateInfo::default().max_sets(odd.len()as u32).pool_sizes(&[vk::DescriptorPoolSize{ty:vk::DescriptorType::STORAGE_IMAGE,descriptor_count:odd.len()as u32*2}]),None).map_err(|e|e.to_string())?;
   let layouts=vec![self.layout;odd.len()];let sets=self.device.allocate_descriptor_sets(&vk::DescriptorSetAllocateInfo::default().descriptor_pool(job.pool).set_layouts(&layouts)).map_err(|e|e.to_string())?;
   for(level,set)in odd.into_iter().zip(sets){
    let mut pair=[vk::ImageView::null();2];
    for(offset,slot)in pair.iter_mut().enumerate(){
     *slot=self.device.create_image_view(&vk::ImageViewCreateInfo::default().image(image).view_type(vk::ImageViewType::TYPE_2D).format(vk::Format::R8G8B8A8_UNORM).subresource_range(vk::ImageSubresourceRange::default().aspect_mask(vk::ImageAspectFlags::COLOR).base_mip_level((level-1+offset)as u32).level_count(1).layer_count(1)),None).map_err(|e|e.to_string())?;job.views.push(*slot);
    }
    let a=[vk::DescriptorImageInfo::default().image_view(pair[0]).image_layout(vk::ImageLayout::GENERAL)];let b=[vk::DescriptorImageInfo::default().image_view(pair[1]).image_layout(vk::ImageLayout::GENERAL)];
    self.device.update_descriptor_sets(&[vk::WriteDescriptorSet::default().dst_set(set).dst_binding(0).descriptor_type(vk::DescriptorType::STORAGE_IMAGE).image_info(&a),vk::WriteDescriptorSet::default().dst_set(set).dst_binding(1).descriptor_type(vk::DescriptorType::STORAGE_IMAGE).image_info(&b)],&[]);job.sets[level]=set;
   }
  }Ok(job)
 }
 pub(super) unsafe fn record(&self,job:&Job,command:vk::CommandBuffer,level:usize,width:u32,height:u32){
  unsafe{self.device.cmd_bind_pipeline(command,vk::PipelineBindPoint::COMPUTE,self.pipeline);self.device.cmd_bind_descriptor_sets(command,vk::PipelineBindPoint::COMPUTE,self.pipeline_layout,0,&[job.sets[level]],&[]);self.device.cmd_dispatch(command,width.div_ceil(8),height.div_ceil(8),1);}
 }
}
pub(super) fn needs_area(width:u32,height:u32)->bool{(width>1&&width%2!=0)||(height>1&&height%2!=0)}
pub(super) struct Job{device:Device,lifetime:Arc<Lifetime>,pool:vk::DescriptorPool,views:Vec<vk::ImageView>,sets:Vec<vk::DescriptorSet>}
impl Drop for Job{fn drop(&mut self){if self.lifetime.uncertain(){return;}unsafe{self.device.destroy_descriptor_pool(self.pool,None);for view in self.views.drain(..){self.device.destroy_image_view(view,None);}}}}
impl Drop for Pipeline{fn drop(&mut self){if self.lifetime.uncertain(){return;}unsafe{self.device.destroy_pipeline(self.pipeline,None);self.device.destroy_pipeline_layout(self.pipeline_layout,None);self.device.destroy_descriptor_set_layout(self.layout,None);}}}
