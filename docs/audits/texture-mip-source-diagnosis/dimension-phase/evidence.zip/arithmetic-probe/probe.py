import ctypes as C,json,sys
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QOffscreenSurface,QOpenGLContext,QSurfaceFormat
fmt=QSurfaceFormat();fmt.setVersion(4,3);fmt.setProfile(QSurfaceFormat.CoreProfile);QSurfaceFormat.setDefaultFormat(fmt)
app=QApplication([]);surface=QOffscreenSurface();surface.setFormat(fmt);surface.create();ctx=QOpenGLContext();ctx.setFormat(fmt);assert ctx.create()and ctx.makeCurrent(surface)
gl=C.CDLL('libGL.so.1')
def api(name,ret,*args):
 f=getattr(gl,name);f.restype=ret;f.argtypes=list(args);return f
U=C.c_uint;I=C.c_int;P=C.c_void_p
getstr=api('glGetString',C.c_char_p,U);assert b'NVIDIA'in getstr(0x1F00)
create=api('glCreateShader',U,U);source=api('glShaderSource',None,U,I,C.POINTER(C.c_char_p),C.POINTER(I));compile=api('glCompileShader',None,U);query=api('glGetShaderiv',None,U,U,C.POINTER(I));log=api('glGetShaderInfoLog',None,U,I,C.POINTER(I),P)
shader=create(0x91B9)
text=b'#version 430\nlayout(local_size_x=1)in;layout(std430,binding=0)readonly buffer D{uvec4 dims[];};layout(std430,binding=1)writeonly buffer R{float values[];};\nvoid main(){uint i=gl_GlobalInvocationID.x;uvec4 d=dims[i];float w=float(d.z),h=float(d.w),a=w*h;uint o=i*8;values[o]=1.0/a;values[o+1]=1.0/w;values[o+2]=1.0/h;values[o+3]=h/a;values[o+4]=w/a;values[o+5]=(1.0/a)*a;values[o+6]=(h/a)*w;values[o+7]=fma(float(d.x),h/a,-2.0);}\n'
ptr=C.c_char_p(text);source(shader,1,C.byref(ptr),None);compile(shader);ok=I();query(shader,0x8B81,C.byref(ok))
if not ok.value:
 b=C.create_string_buffer(8192);log(shader,8192,None,b);raise RuntimeError(b.value)
program=api('glCreateProgram',U)();api('glAttachShader',None,U,U)(program,shader);api('glLinkProgram',None,U)(program);api('glGetProgramiv',None,U,U,C.POINTER(I))(program,0x8B82,C.byref(ok));assert ok.value
api('glUseProgram',None,U)(program)
cases=json.loads(Path('/input/original.json').read_text())['cases'];dims=[v for c in cases for v in[c['levels'][0]['width'],c['levels'][0]['height'],c['levels'][1]['width'],c['levels'][1]['height']]];arr=(U*len(dims))(*dims);out=(C.c_float*(8*len(cases)))();buffers=(U*2)();api('glGenBuffers',None,I,C.POINTER(U))(2,buffers);bind=api('glBindBuffer',None,U,U);data=api('glBufferData',None,U,C.c_ssize_t,P,U);base=api('glBindBufferBase',None,U,U,U)
for i,(value,size)in enumerate([(arr,C.sizeof(arr)),(None,C.sizeof(out))]):bind(0x90D2,buffers[i]);data(0x90D2,size,value,0x88E8);base(0x90D2,i,buffers[i])
api('glDispatchCompute',None,U,U,U)(len(cases),1,1);api('glMemoryBarrier',None,U)(0xffffffff);bind(0x90D2,buffers[1]);api('glGetBufferSubData',None,U,C.c_ssize_t,C.c_ssize_t,P)(0x90D2,0,C.sizeof(out),out);assert api('glGetError',U)()==0
rows=[{'asset':c['asset'],'dims':dims[i*4:(i+1)*4],'values':list(out[i*8:(i+1)*8])}for i,c in enumerate(cases)];Path('/out/arithmetic.json').write_text(json.dumps({'renderer':getstr(0x1F01).decode(),'version':getstr(0x1F02).decode(),'scope':'Standalone NVIDIA GL compute arithmetic observation; not original mip shader or production renderer','cases':rows},indent=2));print('Observed',len(rows),'GPU arithmetic cases')
