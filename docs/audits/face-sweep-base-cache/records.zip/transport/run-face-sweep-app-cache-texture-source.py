import subprocess,json,time,hashlib,os
from pathlib import Path
out=Path('/tmp/face-sweep-app-cache-texture-source');out.mkdir(mode=0o700)
query=lambda *args:subprocess.check_output(args,text=True).strip()
merged=query('podman','inspect','ingetrazo-publish','--format','{{.GraphDriver.Data.MergedDir}}');image=query('podman','inspect','ingetrazo-publish','--format','{{.Image}}');name='face-sweep-app-'+str(os.getpid())
(out/'nvidia.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':'libGLX_nvidia.so.0','api_version':'1.3.242'}}))
args=['podman','run','--rm','--name',name,'--read-only','--network','none','--device','nvidia.com/gpu=0','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw']
for left,right in [('/usr/lib/libEGL.so.1','/usr/lib/libEGL.so.1'),('/usr/lib/libGLdispatch.so.0','/usr/lib/libGLdispatch.so.0'),(merged+'/tmp/ingetrazo-parity-python','/tmp/ingetrazo-parity-python'),(merged+'/usr/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu'),(merged+'/usr/bin','/usr/bin'),(merged+'/usr/share','/usr/share'),(merged+'/etc/alternatives','/etc/alternatives'),(merged+'/etc/fonts','/etc/fonts'),(merged+'/etc/ImageMagick-6','/etc/ImageMagick-6'),(merged+'/tmp/ingetrazo-hidden-ghost/scripts','/probe'),('/tmp/face-sweep-app-frozen-cache','/app'),('/tmp/face-sweep-source-label-4','/input')]:args+=['-v',left+':'+right+':ro']
args+=['-v',str(out)+':/out:rw','-e','VK_DRIVER_FILES=/out/nvidia.json','-e','XDG_CACHE_HOME=/tmp/cache',image,'/tmp/ingetrazo-parity-python/bin/python','/probe/check-native-face-sweep-application.py','/app','/out','--source','a27e0bd350342d7a1ea2556dd56d42e8f09bce50','--source-dir','/input','--case','front-texture-back-override','--source-frames']
start=time.monotonic();rc=124
try:
 with (out/'transport.log').open('w')as f:rc=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=70).returncode
finally:
 subprocess.run(['podman','rm','--force',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
 metadata={'compiled_source':'a27e0bd350342d7a1ea2556dd56d42e8f09bce50','binary_sha256':hashlib.sha256(Path('/tmp/face-sweep-app-frozen-cache').read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(merged+'/tmp/ingetrazo-hidden-ghost/scripts/check-native-face-sweep-application.py').read_bytes()).hexdigest(),'command':args,'image':image,'returncode':rc,'elapsed_seconds':time.monotonic()-start};(out/'transport.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({'returncode':rc,'elapsed_seconds':metadata['elapsed_seconds']}))
raise SystemExit(rc)
