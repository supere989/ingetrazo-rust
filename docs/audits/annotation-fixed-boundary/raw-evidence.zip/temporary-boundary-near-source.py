#!/usr/bin/env python3
"""Owned Qt OpenGL widget primitive source controls; diagnostic, not import proof."""
import ctypes,json,sys,hashlib
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtGui import QPainter,QPen,QColor,QPolygonF,QSurfaceFormat
from PySide6.QtCore import QPointF,Qt,QTimer,qVersion
out=Path(sys.argv[-1]);out.mkdir(parents=True,exist_ok=True)
assert qVersion().startswith('6.12.')
fmt=QSurfaceFormat();fmt.setVersion(3,3);fmt.setProfile(QSurfaceFormat.CompatibilityProfile);fmt.setSamples(0);fmt.setAlphaBufferSize(0);fmt.setDepthBufferSize(24);fmt.setStencilBufferSize(8)
QSurfaceFormat.setDefaultFormat(fmt)
ink=[45,55,75,255]
def line(name,a,b,w):return {'name':name,'operations':[{'kind':'line','a':a,'b':b,'width':w,'pen':ink,'brush':ink}]}
rows=[]
for name,pts in [
 ('top-boundary',[[20.5,20.4999],[80.5,20.4999],[20.5,80.5]]),
 ('bottom-boundary',[[20.5,80.5001],[80.5,80.5001],[20.5,20.5]]),
 ('left-boundary',[[20.5,20.25],[20.5,80.25],[80.25,50.25]]),
 ('right-boundary',[[80.5,20.25],[80.5,80.25],[20.25,50.25]])]:
 rows.append({'name':name,'operations':[{'kind':'polygon','points':pts,'width':0,'pen':[0,0,0,255],'brush':[17,89,203,255]}]})
app=QApplication([])
class Widget(QOpenGLWidget):
 def __init__(self):
  super().__init__();self.row=0;self.paints=0;self.records=[];self.setFormat(fmt);self.setFixedSize(800,600);self.setWindowFlag(Qt.WindowTransparentForInput);self.setWindowFlag(Qt.WindowDoesNotAcceptFocus)
 def paintGL(self):
  self.paints+=1;p=QPainter(self);p.setRenderHint(QPainter.Antialiasing,True);p.fillRect(self.rect(),QColor(255,255,255));p.setClipRect(0,0,640,400)
  for op in rows[self.row]['operations']:
   if op['kind']=='line':p.setPen(QPen(QColor(*op['pen']),op['width']));p.drawLine(QPointF(*op['a']),QPointF(*op['b']))
   else:p.setPen(Qt.NoPen);p.setBrush(QColor(*op['brush']));p.drawPolygon(QPolygonF([QPointF(*v)for v in op['points']]))
  self.engine=p.paintEngine().type().value;p.end()
 def capture(self):
  im=self.grabFramebuffer();assert im.size().width()==800 and im.size().height()==600
  self.makeCurrent();gl=ctypes.CDLL('libGL.so.1');gl.glGetString.restype=ctypes.c_char_p;renderer=gl.glGetString(0x1f01).decode();samples=ctypes.c_int();gl.glGetIntegerv(0x80a9,ctypes.byref(samples));subpixel=ctypes.c_int();gl.glGetIntegerv(0x0d50,ctypes.byref(subpixel));version=gl.glGetString(0x1f02).decode();self.doneCurrent()
  assert 'NVIDIA' in renderer or '5090' in renderer;assert samples.value==0 and self.engine==13
  path=out/(rows[self.row]['name']+'.png');assert im.save(str(path));self.records.append(dict(rows[self.row],framebuffer=[im.width(),im.height()],clip=[0,0,640,400],renderer=renderer,samples=samples.value,subpixel_bits=subpixel.value,gl_version=version,engine=self.engine,paints=self.paints,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
  self.row+=1
  if self.row==len(rows):
   (out/'original.json').write_text(json.dumps({'source_pin':'6be29fe437a7cd992d4e079f71720821b25216b9','qt':qVersion(),'scope':'actual Qt OpenGL widget painter primitive controls; not original import/view geometry','cases':self.records},indent=2)+'\n');self.close();app.quit()
  else:self.update();QTimer.singleShot(80,self.capture)
w=Widget();w.show();QTimer.singleShot(500,w.capture);QTimer.singleShot(10000,lambda:sys.exit('bounded Qt primitive capture missed completion'));raise SystemExit(app.exec())
