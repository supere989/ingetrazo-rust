from pathlib import Path
import subprocess,os,time,json,hashlib,sys
kind,number=sys.argv[1:]
assert kind in ('source','native') and number.isdigit()
root=Path('/tmp/ingetrazo-next-integration');os.chdir(root)
attempt=Path(f'/tmp/ingetrazo-axis-{kind}-attempt-{number}');attempt.mkdir()
output=f'/tmp/ingetrazo-axis-{kind}-r{number}'
source='/tmp/ingetrazo-ai-bridge-capture-source-r1'
if kind=='source':
 executable=Path('/tmp/ingetrazo-parity-python/bin/python');script=Path('scripts/reference-axis-transport.py');command=[str(executable),str(script),source,output]
else:
 executable=Path('/tmp/ingetrazo-native-font-merge-target/debug/examples/ai_bridge_capture_workflows');command=[str(executable),source,output,'--axis-transport-only']
with (attempt/'xvfb.log').open('w') as xvlog:
 server=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=xvlog,text=True)
 try:
  display=server.stdout.readline().strip();assert display.isdigit()
  env=dict(os.environ,DISPLAY=':'+display,QT_QPA_PLATFORM='xcb',LIBGL_ALWAYS_SOFTWARE='1',WINIT_UNIX_BACKEND='x11',VK_ICD_FILENAMES='/usr/share/vulkan/icd.d/lvp_icd.json')
  receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'command':command,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'images_captured':0}
  if kind=='source':receipt.update(script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path('docs/audits/axis-transport/fixture-contract.json').read_bytes()).hexdigest())
  else:receipt['binary_sha256']=hashlib.sha256(executable.read_bytes()).hexdigest()
  started=time.monotonic()
  with (attempt/'stdout').open('w') as stdout,(attempt/'stderr').open('w') as stderr:
   try:result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=45);code=result.returncode
   except subprocess.TimeoutExpired:code=124
  receipt.update(returncode=code,seconds=time.monotonic()-started)
  (attempt/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt));print((attempt/'stderr').read_text()[-1200:]);raise SystemExit(code)
 finally:
  server.terminate();server.wait(timeout=5)
