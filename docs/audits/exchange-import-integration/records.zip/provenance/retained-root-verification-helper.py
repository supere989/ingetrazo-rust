from pathlib import Path
import subprocess,time,json,sys,hashlib,os
repo=Path('/tmp/ingetrazo-next-integration');source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
binary=Path('/tmp/ingetrazo-native-font-merge-target/debug/examples/exchange_import_workflows')
result={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'fresh_source_captures':0,'steps':[]}
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',INGETRAZO_PDF_UI_OBSERVE='1')
argvs=[('native',[str(binary),str(source),str(out/'native')]),('reader',['/tmp/ingetrazo-parity-python/bin/python','scripts/reference-exchange-import-reopens.py',str(source),str(out/'native')]),('checker',['/tmp/ingetrazo-parity-python/bin/python','scripts/check-exchange-import.py',str(source),str(out/'native'),str(out/'comparison.json')])]
try:
 for label,argv in argvs:
  t=time.monotonic()
  with(out/(label+'.log')).open('w')as log:r=subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  step={'label':label,'argv':argv,'seconds':time.monotonic()-t,'returncode':r.returncode};result['steps'].append(step);print(json.dumps(step),flush=True)
  if r.returncode:break
except Exception as e:result['error']=repr(e)
finally:(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
