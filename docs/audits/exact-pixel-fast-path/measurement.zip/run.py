import os,sys,time,subprocess,json
from pathlib import Path
w=Path(__file__).resolve().parent
mode=sys.argv[1]
script=w/'old-reader.py' if mode=='old' else Path('/tmp/ingetrazo-next-integration/scripts/check-sheet-view-vector-pdf.py')
env=os.environ.copy();env['QT_QPA_PLATFORM']='offscreen'
started=time.monotonic()
with (w/(mode+'.log')).open('w') as log:
 r=subprocess.run(['/tmp/ingetrazo-parity-python/bin/python',str(script),str(w/'pages'),'300'],stdout=log,stderr=subprocess.STDOUT,env=env)
(w/(mode+'-timing.json')).write_text(json.dumps({'exit':r.returncode,'seconds':time.monotonic()-started}))
if r.returncode==0:(w/(mode+'-result.json')).write_bytes((w/'pages/reader-300.json').read_bytes())
raise SystemExit(r.returncode)
