import subprocess,pathlib,json,hashlib,time,sys
inspect=lambda f:subprocess.check_output(['podman','inspect','ingetrazo-publish','--format',f],text=True).strip()
merged=inspect('{{.GraphDriver.Data.MergedDir}}');image=inspect('{{.Image}}')
root=pathlib.Path('/tmp/texture-perf-final-gpu');root.mkdir(exist_ok=True)
variants=sys.argv[1:] or ['baseline']
for n,v in enumerate(variants):
 out=root/f'{n:02}-{v}';out.mkdir(exist_ok=True)
 (out/'icd.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':'/usr/lib/libEGL_nvidia.so.0','api_version':'1.4.351'}}))
 binary=merged+f'/tmp/texture-cold-{v}-frozen';name=f'ingetrazo-texture-perf-{n}'
 cmd=['podman','run','--rm','--name',name,'--read-only','--network','none','--device','nvidia.com/gpu=0','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw','-v','/usr/lib/libEGL.so.1:/usr/lib/libEGL.so.1:ro','-v','/usr/lib/libGLdispatch.so.0:/usr/lib/libGLdispatch.so.0:ro','-v',binary+':/probe:ro','-v',merged+'/tmp/texture-perf-reference:/input:ro','-v',str(out)+':/out:rw','-e','VK_DRIVER_FILES=/out/icd.json',image,'/probe','/input','/out']
 start=time.monotonic()
 try:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(out/'runtime.log').write_text(p.stdout+p.stderr)
  (out/'transport.json').write_text(json.dumps({'command':cmd,'binary_sha256':hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),'returncode':p.returncode,'elapsed':time.monotonic()-start},indent=2))
  print(v,p.returncode,(out/'runtime.log').read_text()[-1000:],flush=True)
  if p.returncode:sys.exit(p.returncode)
 finally:subprocess.run(['podman','rm','--force',name],capture_output=True,timeout=10)
