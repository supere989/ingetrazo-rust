use ingetrazo_metal::{NativeMetal, MTLDevice as _};
fn capability(metal: &NativeMetal) -> bool { metal.device.isDepth24Stencil8PixelFormatSupported() }
fn main() {}
