#!/bin/sh
set -eu
cd /tmp/ingetrazo-next-integration
export CARGO_TARGET_DIR=/tmp/ingetrazo-native-font-merge-target
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
export QT_QPA_PLATFORM=offscreen
export XDG_CONFIG_HOME=/tmp/ingetrazo-vector-build-once-proof/config
export XDG_CACHE_HOME=/tmp/ingetrazo-vector-build-once-proof/cache
cargo clean -p ingetrazo-core -p ingetrazo-tools -p ingetrazo-gui > /tmp/ingetrazo-vector-build-once-proof/clean.log 2>&1
/tmp/ingetrazo-parity-python/bin/python scripts/composer_vector_fixtures.py > /tmp/ingetrazo-vector-build-once-proof/build.json 2> /tmp/ingetrazo-vector-build-once-proof/build.log
/tmp/ingetrazo-parity-python/bin/python scripts/check-composer-vector-view-pdf.py /tmp/ingetrazo-vector-build-once-proof/pages --prebuilt-dir /tmp/ingetrazo-native-font-merge-target/debug > /tmp/ingetrazo-vector-build-once-proof/gate.log 2>&1
