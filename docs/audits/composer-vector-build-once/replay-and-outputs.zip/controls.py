import importlib.util, json, os, subprocess
from pathlib import Path
from unittest.mock import patch
repo=Path("/tmp/ingetrazo-next-integration")
out=Path("/tmp/ingetrazo-vector-build-once-proof")
spec=importlib.util.spec_from_file_location("fixtures",repo/"scripts/composer_vector_fixtures.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
checks=[]
for label, message in [("missing_cargo_artifacts", []),("wrong_artifact_path", [{"reason":"compiler-artifact","target":{"name":"sheet_view_pdf_fixture","kind":["example"]},"executable":"/foreign/target/debug/examples/sheet_view_pdf_fixture"}]),("wrong_artifact_kind", [{"reason":"compiler-artifact","target":{"name":"sheet_view_pdf_fixture","kind":["bin"]},"executable":str(Path(os.environ["CARGO_TARGET_DIR"])/"debug/examples/sheet_view_pdf_fixture")}])]:
    with patch.object(module.subprocess,"run",return_value=subprocess.CompletedProcess([],0,stdout="\n".join(json.dumps(m) for m in message))) as cargo:
        try: module.build()
        except ValueError as e:
            assert "missing Cargo artifact" in str(e)
        else: raise AssertionError(label+" accepted")
        assert cargo.call_count==1
        command=cargo.call_args.args[0]
        assert command.count("--example")==3 and command.count("--bin")==1 and command.count("-p")==3
    checks.append(label)
with patch.dict(os.environ,{"CARGO_BUILD_TARGET":"aarch64-apple-darwin"}), patch.object(module.subprocess,"run") as cargo:
    try: module.build()
    except ValueError as e: assert "native debug" in str(e)
    else: raise AssertionError("Cross target accepted")
    cargo.assert_not_called()
checks.append("cross_target_rejected_before_build")
missing_output=out/"missing-output-must-not-be-created"
result=subprocess.run(["python3",str(repo/"scripts/check-composer-vector-view-pdf.py"),str(missing_output),"--prebuilt-dir",str(out/"missing-consumers")],capture_output=True,text=True,cwd=repo)
assert result.returncode==2 and "Required prebuilt executable missing" in result.stderr
assert not missing_output.exists()
(out/"missing-prebuilt.log").write_text(result.stderr)
checks.append("missing_prebuilt_rejected_before_source_capture")
(out/"controls.json").write_text(json.dumps({"passed":True,"checks":checks,"mocked_build_controls":4,"real_missing_prebuilt_invocation":1},indent=2)+"\n")
print(json.dumps({"passed":True,"checks":checks}))
