#!/usr/bin/env python3
# Preserved producer of composite64.json (initially executed via stdin).
# Intermediate arithmetic diagnostic, not a full-page source recapture or native execution.
from PySide6.QtGui import QImage,QPainter
from PySide6.QtCore import QRectF,Qt
from PySide6.QtWidgets import QApplication
import numpy as np,json
from pathlib import Path
app=QApplication([]);src=QImage("/tmp/ingetrazo-dem-picture-integration/pictures/source/assets/checker.png"); im=src.convertToFormat(QImage.Format_RGBA8888);a=np.frombuffer(im.constBits(),np.uint8).reshape(im.height(),im.bytesPerLine())[:,:im.width()*4].reshape(im.height(),im.width(),4).astype(np.uint64)*257
out=[]
for fit in ["stretch","cover"]:
 sw,sh=src.width(),src.height();aspect=47/33;s=[0.,0.,float(sw),float(sh)]
 if fit=="cover":s[3]=sw/aspect;s[1]=(sh-s[3])/2
 W,H=round(s[2]),round(s[3]) if fit=="cover" else round(sw/aspect)
 q=QImage(W,H,QImage.Format_ARGB32);q.fill(Qt.transparent);p=QPainter(q);p.setRenderHint(QPainter.SmoothPixmapTransform,True);p.drawImage(QRectF(0,0,W,H),src,QRectF(*s));p.end();r=q.convertToFormat(QImage.Format_RGBA8888);r=np.frombuffer(r.constBits(),np.uint8).reshape(H,r.bytesPerLine())[:,:W*4].reshape(H,W,4).copy()
 mx=1/(W/s[2]);my=1/(H/s[3]);fx=np.int64((.5*mx+s[0])*65536)-32768+np.arange(W,dtype=np.int64)*int(mx*65536);fy=np.array([int(((y+.5)*my+s[1])*65536)-32768 for y in range(H)],np.int64)
 x=fx>>16;y=fy>>16;dx=(fx&65535).astype(np.uint64)[None,:,None];dy=(fy&65535).astype(np.uint64)[:,None,None]
 def get(x,y):return a[np.clip(y,0,sh-1)[:,None],np.clip(x,0,sw-1)[None,:]]
 def blend(a,b,t):return np.where(t==0,a,((a*(65536-t))>>16)+((b*t)>>16))
 b=blend(blend(get(x,y),get(x,y+1),dy),blend(get(x+1,y),get(x+1,y+1),dy),dx)
 v=b+128;v=((v-(v>>8))>>8).astype(np.uint8)
 # All source pixels here are opaque. This diagnostic uses f32 division;
 # production correction separately mirrors Qt SSE reciprocal/Newton store.
 alpha=b[:,:,3].astype(np.float32);v[:,:,:3]=np.rint(b[:,:,:3].astype(np.float32)*(np.float32(255)/alpha[:,:,None])).clip(0,255).astype(np.uint8)
 diff=np.any(v!=r,axis=2);out.append(dict(fit=fit,size=[W,H],different=int(diff.sum()),maxerror=int(np.abs(v.astype(int)-r.astype(int)).max()),examples=[dict(x=int(x),y=int(y),qt=r[y,x].tolist(),candidate=v[y,x].tolist()) for y,x in np.argwhere(diff)[:5]]))
Path("/tmp/ingetrazo-sheet-picture-proof/diagnostic/composite64.json").write_text(json.dumps(out,indent=2));print(json.dumps(out))
