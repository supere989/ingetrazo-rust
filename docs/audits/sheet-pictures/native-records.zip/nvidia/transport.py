import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('source');parser.add_argument('output');args=parser.parse_args()
def query(*args):return subprocess.check_output(args,text=True).strip()
repo='/tmp/ingetrazo-next-integration';target='/tmp/ingetrazo-native-font-merge-target/debug'
merged=query('podman','inspect','ingetrazo-publish','--format','{{.GraphDriver.Data.MergedDir}}');container_image=query('podman','inspect','ingetrazo-publish','--format','{{.Image}}')
revision=query('podman','exec','ingetrazo-publish','git','-C',repo,'rev-parse','HEAD');binary_sha=query('podman','exec','ingetrazo-publish','sha256sum',target+'/examples/sheet_picture_workflows').split()[0]
out=Path(args.output).resolve();out.mkdir(mode=0o700,exist_ok=False)
(out/'nvidia.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':'libGLX_nvidia.so.0','api_version':'1.3.242'}}))
name='ingetrazo-sheet-pictures-'+str(os.getpid())
command=['podman','--cdi-spec-dir','/tmp/ingetrazo-nvidia-61571/cdi','run','--rm','--name',name,'--read-only','--network','none','--device','nvidia.com/gpu=0','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw']
mounts=[('/usr/lib/libEGL.so.1','/usr/lib/libEGL.so.1'),('/usr/lib/libGLdispatch.so.0','/usr/lib/libGLdispatch.so.0'),(merged+'/usr/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu'),(merged+'/usr/bin','/usr/bin'),(merged+'/usr/share','/usr/share'),(merged+'/etc/alternatives','/etc/alternatives'),(merged+'/etc/fonts','/etc/fonts'),(merged+target,'/native')]
for left,right in mounts:command+=['-v',left+':'+right+':ro']
# Only the authenticated extracted fixture is writable for the snapshot/restore guard.
command+=['-v',merged+args.source+':/source:rw','-v',str(out)+':/out:rw','-v',str(out/'nvidia.json')+':/nvidia.json:ro','-e','VK_DRIVER_FILES=/nvidia.json','-e','XDG_CONFIG_HOME=/tmp/sheet-picture-config','-e','XDG_DATA_HOME=/tmp/sheet-picture-data',container_image,'/native/examples/sheet_picture_workflows','/source','/out/native']
started=time.monotonic();code=124
try:
 with(out/'transport.log').open('w')as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
finally:subprocess.run(['podman','rm','--force',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
receipt=dict(revision=revision,binary_sha256=binary_sha,image=container_image,argv=command,returncode=code,seconds=time.monotonic()-started,private_cdi_sha256=hashlib.sha256(Path('/tmp/ingetrazo-nvidia-61571/cdi/nvidia.yaml').read_bytes()).hexdigest())
(out/'transport.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert code==0,(out/'transport.log').read_text()
assert 'Selected headless adapter NVIDIA GeForce RTX 5090' in (out/'transport.log').read_text()
assert binary_sha==query('podman','exec','ingetrazo-publish','sha256sum',target+'/examples/sheet_picture_workflows').split()[0]
print(json.dumps({k:receipt[k]for k in ['returncode','seconds','revision','binary_sha256']}))
