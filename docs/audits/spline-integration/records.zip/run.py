from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
repo=Path('/tmp/ingetrazo-next-integration');out=Path(__file__).resolve().parent
target=Path('/tmp/ingetrazo-native-font-merge-target');source_python='/tmp/ingetrazo-parity-python/bin/python'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',QT_QPA_PLATFORM='offscreen')
receipt={'runtime_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'fresh_source_captures':0,'broad_local_runs':0,'stages':[],'archives':{},'binaries':{}}
def stage(name,argv,lane=None):
 path=out/(name+'.log');path.parent.mkdir(parents=True,exist_ok=True)
 runenv=dict(env)
 if lane:
  runenv.update(INGETRAZO_STATE_DIR=str(out/lane/'state'),XDG_CONFIG_HOME=str(out/lane/'config'),XDG_DATA_HOME=str(out/lane/'data'),XDG_CACHE_HOME=str(out/lane/'cache'))
 start=time.monotonic()
 with path.open('w')as log:r=subprocess.run(list(map(str,argv)),cwd=repo,env=runenv,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 receipt['stages'].append({'name':name,'argv':list(map(str,argv)),'seconds':time.monotonic()-start,'exit_code':r.returncode})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if r.returncode:raise RuntimeError(name+' failed: '+str(r.returncode))
def source(package,lane,selected=None):
 folder=repo/'docs/audits'/package;manifest=json.loads((folder/'source-manifest.json').read_text());raw=(folder/'source-records.zip').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==manifest['archive_sha256'];rows=manifest.get('entries',manifest.get('records',manifest.get('members')))
 if isinstance(rows,dict):rows=[{'path':k,**v}for k,v in rows.items()]
 with zipfile.ZipFile(folder/'source-records.zip')as z:
  assert set(z.namelist())=={r['path']for r in rows}
  for r in rows:
   data=z.read(r['path']);assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
   if selected is None or r['path']in selected:
    dst=out/lane/r['path'];assert dst.resolve().is_relative_to((out/lane).resolve());dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 receipt['archives'][package]=digest
assert subprocess.check_output(['git','-C','/work/ingetrazo','rev-parse','HEAD'],text=True).strip()=='6be29fe437a7cd992d4e079f71720821b25216b9'
source('dxf-legacy-polylines','dxf-entities');source('dxf-curves','dxf-curves');source('dxf-splines','dxf-splines')
names=['context_document_lifecycle'];cmd=['cargo','build','--locked','--offline','-p','ingetrazo-gui']
for name in names:cmd+=['--example',name]
stage('combined-build',cmd)
for name in names:receipt['binaries'][name]=hashlib.sha256((target/'debug/examples'/name).read_bytes()).hexdigest()
for lane,mode,reader,checker in [('dxf-entities','--dxf-entities','reference-dxf-entities-reopens.py','check-dxf-entities.py'),('dxf-curves','--dxf-curves','reference-dxf-curves-reopens.py','check-dxf-source-curves.py'),('dxf-splines','--dxf-splines','reference-dxf-splines-reopens.py','check-dxf-source-splines.py')]:
 folder=out/lane;stage(lane+'/runtime',[target/'debug/examples/context_document_lifecycle',folder,mode],lane);stage(lane+'/reopen',[source_python,repo/'scripts'/reader,folder],lane);stage(lane+'/check',['python3',repo/'scripts'/checker,folder],lane)
receipt['result']='pass';receipt['semantic_seconds']=sum(r['seconds']for r in receipt['stages']if '/'in r['name']);receipt['crates_tree']=subprocess.check_output(['git','rev-parse','HEAD:crates'],cwd=repo,text=True).strip()
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
