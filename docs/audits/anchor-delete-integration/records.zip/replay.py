import ast, hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
repo=Path('/tmp/ingetrazo-next-integration')
out=Path(__file__).resolve().parent
binaries=Path('/tmp/ingetrazo-native-font-merge-target/debug')
pin='6be29fe437a7cd992d4e079f71720821b25216b9'
assert subprocess.check_output(['git','-C',str(repo/'ingetrazo'),'rev-parse','HEAD'],text=True).strip()==pin
runner=repo/'scripts/check-document-axes-integration.py'
node=next(n for n in ast.parse(runner.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='archive')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(runner),'exec'))
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',INGETRAZO_STATE_DIR=str(out/'state'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'),XDG_CACHE_HOME=str(out/'cache'))
def run(cmd,log):
 with (out/log).open('w') as f:subprocess.run([str(x)for x in cmd],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
a=out/'anchors';d=out/'delete'
cases=['near','outside','nested-shared','billboard','orphan']
archives={}
archives['anchors']=archive('dimension-anchor-admission','manifest.json',[c+e for c in cases for e in ['-input.igz','-original.igz']]+['admission-original.json','first-native-inverse-mismatch.json'],a)
archives['delete']=archive('annotation-delete','manifest.json',['delete-input.igz','original.json']+[c+'-original.igz' for c in ['root','nested-annotations','nested-mixed','parked']],d)
archives['hover_delete']=archive('annotation-hover-delete','manifest.json',['hover-input.igz','hover-delete-original.json'],d)
t=time.monotonic()
run([binaries/'examples/dimension_anchor_acceptance_fixture',a,'--admission'],'anchors/runtime.log')
run([sys.executable,repo/'scripts/check-dimension-anchor-admission.py',a],'anchors/acceptance.json')
run([sys.executable,repo/'scripts/reopen-dimension-anchor-admission.py',a],'anchors/reopen-acceptance.json')
run([binaries/'examples/annotation_delete_fixture',d],'delete/runtime.log')
run([sys.executable,repo/'scripts/check-annotation-delete.py',d],'delete/acceptance.json')
run([sys.executable,repo/'scripts/check-annotation-delete-reopen.py',d],'delete/reopen-acceptance.json')
seconds=time.monotonic()-t
files=['crates/ingetrazo-core/src/dimension_anchors.rs','crates/ingetrazo-gui/examples/dimension_anchor_acceptance_fixture.rs','crates/ingetrazo-gui/examples/annotation_delete_fixture.rs','scripts/check-dimension-anchor-admission.py','scripts/reopen-dimension-anchor-admission.py','scripts/check-annotation-delete.py','scripts/check-annotation-delete-reopen.py','scripts/check-document-axes-integration.py','.github/workflows/parity.yml']
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=dict(runtime_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source_pin=pin,seconds=seconds,build=json.loads((out/'build.json').read_text()),source_archives=archives,binaries={str(p.relative_to(binaries)):digest(p)for p in [binaries/'ingetrazo',binaries/'examples/dimension_anchor_acceptance_fixture',binaries/'examples/annotation_delete_fixture']},source_files={str(p):digest(repo/p)for p in files},anchors=json.loads((a/'acceptance.json').read_text()),anchor_reopens=json.loads((a/'reopen-acceptance.json').read_text()),delete=json.loads((d/'acceptance.json').read_text()),delete_reopens=json.loads((d/'reopen-acceptance.json').read_text()),fresh_source_captures=0)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
