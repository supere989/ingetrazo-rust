# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Marco Sumari Tellez and IngeTrazo contributors.
"""Scene container, backed by a shared-vertex :class:`~core.mesh.Mesh`.

``edges`` and ``faces`` are read-only views onto the mesh (lists of
``mesh.Edge`` / ``mesh.Face``), so render, bounds and ``.igz`` save consume them
unchanged. Every mutation goes through mesh methods (via the ``Command`` layer),
which keep shared-vertex connectivity and incidence in sync — no more
position-matching to rediscover topology.

``version`` bumps on every mutation so the viewport can cheaply decide whether
to rebuild its dynamic VBOs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from PySide6.QtGui import QVector3D

from core.mesh import Edge, Face, Mesh


def _make_style():
    from core.style import Style
    return Style()


def _make_shadows():
    from core.sun import ShadowSettings
    return ShadowSettings()


@dataclass
class Scene:
    mesh: Mesh = field(default_factory=Mesh)
    selection: set = field(default_factory=set)
    version: int = 0
    #: How many of ``version``'s bumps changed only what is SHOWN -- the
    #: selection -- and not the document. The GL caches key on ``version``
    #: and need every bump; "unsaved changes" must not: a click on empty
    #: space after Ctrl+S asked to save again (issue #159).
    view_version: int = 0
    # Encapsulated chunks (own meshes), isolated from the main mesh's welding.
    groups: list = field(default_factory=list)
    # Annotation entities (static dimensions) — not geometry, drawn as overlays.
    dimensions: list = field(default_factory=list)
    # Leader-text annotations (the Text tool) — same overlay treatment.
    text_labels: list = field(default_factory=list)
    # Georef traced paths (roads / boundaries / alignments) — first-class georef
    # entities, kept out of the topology mesh entirely (Track G).
    geo_paths: list = field(default_factory=list)
    # Imported survey points (GPS / total station, UTM CSV) — reference markers
    # the trace snaps to; never part of the mesh (Track G, municipal flow).
    geo_points: list = field(default_factory=list)
    # Construction guides (Tape Measure): infinite dashed lines / points used to
    # align real drawing. Scaffolding, never part of the mesh.
    guides: list = field(default_factory=list)
    # Imported reference images (core.image_plane.ImagePlane) — a scanned plan
    # or photo you trace over. Display-only like the terrain and for the same
    # reason (invariant #4): reference to draw on top of, never topology.
    image_planes: list = field(default_factory=list)
    # Layers / tags: labels with visibility + lock. The default
    # layer always exists; entities reference layers by name.
    layers: list = field(default_factory=lambda: [
        __import__("core.layers", fromlist=["Layer"]).Layer(
            __import__("core.layers", fromlist=["DEFAULT_LAYER"]).DEFAULT_LAYER)
    ])
    # Named materials (core.materials.Material), name → Material. The
    # registry gives identity to paint recipes; faces keep their baked
    # attrs (color/texture) as the render truth and optionally carry
    # attrs["mat"] = name. See core/materials.py.
    materials: dict = field(default_factory=dict)
    # Saved views ("Scenes"): named camera + layer-visibility
    # snapshots (core.saved_views.SavedView). Presentation state, no geometry.
    saved_views: list = field(default_factory=list)
    # Sheet compositions (core.composition.Composicion) — the print layouts.
    compositions: list = field(default_factory=list)
    # Scales (1:N) typed by the user in the composer beyond the common
    # presets — kept with the document so every frame of the file offers
    # them again (Marco, 2026-09-02).
    custom_scales: list = field(default_factory=list)
    # Display style for dimension annotations (edited from the Tray).
    #: ``norma`` is the drafting standard the dimensions obey — ISO (and so
    #: the Spanish UNE) or the German/Japanese one. It belongs to the
    #: DOCUMENT and not to the machine: a setting kept in QSettings would
    #: redraw a colleague's dimensions the moment he opened the file
    #: (Marco, 2026-09-17). Absent from an older .igz = ISO, which is what
    #: those files were drawn with.
    #: ``base_step_mm`` is how far apart the rows of a baseline run sit on
    #: PAPER — AutoCAD's DIMDLI, and Marco asked for it as a number he
    #: sets rather than one derived from the text height (2026-09-19).
    #: ``ends`` is what closes the dimension line — ``arrow`` (Rafael's
    #: sheet, the default), ``tick`` (oblique, what every document drew
    #: before the choice existed: a file without the key opens with it)
    #: or ``none``. Asked for by a user of DriveMeca's video («los
    #: extremos no tiene para cambiarla», 2026-09-20).
    #: The camera the document was last saved with — target, distance, yaw,
    #: pitch, fov, perspective — so opening it shows what its author saw
    #: (.skp files keep the camera too). ``None`` = never saved.
    #: @pacaeiro, issue #60: «If I do a New drawing, or open a drawing, the
    #: Camera stays in the position where it was before».
    camera_home: dict | None = None
    #: The model's units (issue #33): the unit a bare number is typed in and
    #: every length is shown in, plus the decimals. Travels in the .igz;
    #: read through ``core.units`` (``fmt_len`` & co.).
    units: dict = field(default_factory=lambda: {"length": "m", "precision": 2})
    #: Extensions' own document data, one JSON-safe value per extension key
    #: (``views.extension_api.ExtensionApp.document_data``). Travels in the
    #: .igz; the core never reads it. Changed through
    #: ``core.history.SetPluginDataCommand`` so each edit is undoable.
    plugin_data: dict = field(default_factory=dict)
    dimension_style: dict = field(default_factory=lambda: {
        "decimals": 2, "units": "m", "font_size": 9, "color": [45, 55, 75],
        "norma": "iso", "base_step_mm": 8.0, "ends": "arrow"})
    # Back-face tint override (RGB 0..1), e.g. adopted from an imported
    # .skp's style so unpainted faces read like they did for the author.
    # ``None`` = the viewport's default blue-grey.
    back_face_color: tuple | None = None
    # Active display style (Styles): face mode, edges, background.
    # The viewport reads it every frame; scenes snapshot it (core/style.py).
    display_style: object = field(default_factory=lambda: _make_style())
    # Sun shadows (core/sun.py): whether they draw, and the local date/time
    # the sun stands at. Document data — the shadow study is a deliverable.
    shadows: object = field(default_factory=lambda: _make_shadows())
    # Section planes (core/section.py). At most ONE is
    # ``active`` (the cut) in the model context; the two flags mirror
    # View ▸ Section Planes / Section Cuts toggles.
    section_planes: list = field(default_factory=list)
    show_section_planes: bool = True
    # View ▸ Hidden Objects / Hidden Geometry: hidden objects
    # (groups, components) and hidden geometry (faces, edges) are drawn
    # as a see-through grid and become selectable — the way back to
    # Unhide ▸ Selected. Never drawn normally: ``entity_visible`` stays
    # False for hidden things; the ghost pass draws them.
    show_hidden_objects: bool = False
    show_hidden_geometry: bool = False
    show_section_cuts: bool = True
    # Georeferencing anchor (Track G). ``None`` until the user sets a datum;
    # once set, geodetic ↔ local-metre conversion goes through it. Terrain and
    # tiles are separate display-only objects added in later phases.
    georef: object | None = None
    # Base-map tile layer (Track G, G1) — display-only, never welded into the
    # mesh. Runtime state (not serialised as geometry); requires ``georef``.
    tile_layer: object | None = None
    # 3D draped terrain (Track G, G2 full) — display-only relief mesh, runtime.
    terrain: object | None = None
    # Photogrammetric survey (Track G, G6) — the drone flight's own textured
    # mesh from WebODM/ODM. Display-only like the terrain, and for the same
    # reason: hundreds of thousands of reconstruction triangles are reference
    # geometry to trace over, never topology-engine geometry (invariant #4).
    photo_mesh: object | None = None
    # BIM "active class" (tag-as-you-draw): while set, faces created by the
    # drawing tools are stamped with this tag ({"id", "class", "name"}) at
    # commit time. Runtime UI mode — never serialised.
    active_ifc: object | None = None
    # Group-edit context (Groups v2): while set, ``mesh`` POINTS AT the edited
    # group's mesh so every tool/command works inside the group transparently;
    # ``_loose_mesh`` keeps the real loose mesh for render and restore.
    # ``edit_group`` is the INNERMOST open group — it mirrors the top of
    # ``_edit_stack``, so the thirty-odd readers that only care about "am I
    # inside a group" keep working unchanged.
    edit_group: object | None = None
    _loose_mesh: object | None = None
    #: The open contexts, outermost first — nested editing. Each
    #: entry is ``{"group", "mesh", "share"}``: the group, the mesh ``scene.mesh``
    #: pointed at before entering it, and its pending instance share-back.
    _edit_stack: list = field(default_factory=list)
    #: While a component INSTANCE is open for editing: ``(group, proto,
    #: xform, state0)`` — the shared definition it left, its placement, and
    #: the temp mesh's snapshot at entry (to tell an edit from a look).
    _edit_share: object | None = None

    # ---- Geometry views (read-only over the *loose* mesh) -------------------
    # Tools, edits and topology operate on this (the loose geometry); groups are
    # walled off so drawing never welds to them.
    @property
    def edges(self) -> list[Edge]:
        return self.mesh.edges

    @property
    def faces(self) -> list[Face]:
        return self.mesh.faces

    # ---- Layers --------------------------------------------------------------
    def layer(self, name: str):
        for ly in self.layers:
            if ly.name == name:
                return ly
        return None

    def _layer_state(self, entity) -> tuple[bool, bool]:
        """(visible, locked) of the layer ``entity`` carries; unknown layer
        names read as the default (visible, unlocked)."""
        from core.layers import layer_of
        ly = self.layer(layer_of(entity))
        if ly is None:
            return True, False
        return ly.visible, ly.locked

    @staticmethod
    def _object_hidden(entity) -> bool:
        """Hide on an OBJECT (a group or component). Edges carry
        a ``hidden`` of their own with older, narrower semantics (they stay
        in the topology and the draw passes skip them themselves), so only
        a group answers here."""
        return bool(getattr(entity, "hidden", False)) \
            and hasattr(entity, "children")

    @staticmethod
    def _face_hidden(entity) -> bool:
        """Hide on a face: ``attrs["hidden"]``."""
        attrs = getattr(entity, "attrs", None)
        return bool(attrs and attrs.get("hidden"))

    def entity_hidden(self, entity) -> bool:
        """Hidden by Hide (object or face) — regardless of the layer, and of
        whether the hidden-things view is on."""
        return self._object_hidden(entity) or self._face_hidden(entity)

    def entity_visible(self, entity) -> bool:
        # A hidden thing is gone from every consumer that asks this —
        # render, pick, snap, bounds, export — whatever its layer says.
        # The hidden-things view does NOT change that: it draws them as a
        # ghost in its own pass and only makes them selectable.
        if self.entity_hidden(entity):
            return False
        return self._layer_state(entity)[0]

    def entity_selectable(self, entity) -> bool:
        if self._object_hidden(entity) and not self.show_hidden_objects:
            return False
        if self._face_hidden(entity) and not self.show_hidden_geometry:
            return False
        visible, locked = self._layer_state(entity)
        return visible and not locked

    def groups_by_uid(self) -> dict:
        """``uid → group`` over the whole tree (nested placements too)."""
        from core.purge import iter_groups
        return {g.uid: g for g in iter_groups(self.groups)}

    # ---- Sections (section planes) -------------------------------------------
    def active_section(self):
        """The section plane currently cutting the model, or ``None``."""
        for sp in self.section_planes:
            if sp.active:
                return sp
        return None

    def set_active_section(self, plane) -> None:
        """Make ``plane`` the ONE active cut (None deactivates all) —
        one active cut per context."""
        for sp in self.section_planes:
            sp.active = sp is plane

    # ---- Group-edit context (Groups v2) --------------------------------------
    def begin_group_edit(self, group) -> None:
        """Enter a group: tools and commands now edit ITS mesh (the usual
        double-click-into-group).

        Entering a CHILD of the group already open pushes a level instead of
        starting over — that is the nesting. Anything else closes what is
        open first.

        A group that owns children used to be BAKED on the way in
        (``materialize``): its nine nested groups became one mesh, and both
        the structure and the per-group chunks were gone. «Es lo que no
        quiero, que se fundan todos los grupos, porque además pierdo
        rendimiento» (Marco, 2026-09-11). Now it enters as it is.

        Entering a component INSTANCE edits a world copy of its shared
        definition; leaving shares the edit back to every copy."""
        anidando = (self.edit_group is not None
                    and group in (getattr(self.edit_group, "children", None) or ()))
        if self.edit_group is not None and not anidando:
            self.end_group_edit()
        anterior = self.mesh
        self._edit_share = None
        # The context's own axes (issue #44), read BEFORE anything below
        # rewrites the placement: drawing inside a group happens on the
        # group's axes, level by level.
        from core.group import group_frame
        frame = group_frame(group)
        if getattr(group, "children", None):
            # A container: its children stay children. What CANNOT stay is a
            # transform on it, because the tools work in world coordinates —
            # so the matrix is pushed down into the children and into its own
            # mesh, which leaves every world position exactly where it was.
            self._bake_container_xform(group)
            if frame is not None:
                # Its matrix went down into the children and its mesh is in
                # world coordinates now: the axes stay, as world axes.
                group.axes = frame
        elif getattr(group, "xform", None) is not None:
            # A component instance: the tools work in world coordinates, so
            # the session edits a world-space COPY of the definition. On
            # leaving, the copy goes back into the shared prototype (local
            # coordinates) and every sibling shows the edit — classic
            # component editing. Make Unique first to edit one copy only.
            from core.group import transformed_mesh
            proto, xform = group.mesh, group.xform
            group.mesh = transformed_mesh(proto, xform)
            group.xform = None
            self._edit_share = (group, proto, xform,
                                group.mesh.capture_state())
        if not self._edit_stack:
            self._loose_mesh = anterior
        self._edit_stack.append(
            {"group": group, "mesh": anterior, "share": self._edit_share,
             "frame": frame})
        self.mesh = group.mesh
        self.edit_group = group
        self.selection.clear()
        self.version += 1

    @staticmethod
    def _bake_container_xform(group) -> None:
        """Push a container's own matrix down into its children and its mesh.

        A group that owns placements is always an instance (``Group.adopt``),
        so moving it composes into ``xform``. Inside it the tools speak world
        coordinates, so the matrix has to come down one level: every child
        matrix takes it on the left, the group's own geometry moves to world,
        and the group is left at identity. Nothing moves in the world.

        Its own geometry moves as a COPY, never in place: a container's mesh
        can be the very prototype its children share (an imported component
        tree is exactly that), and walking those vertices would drag every
        placement with it.
        """
        from PySide6.QtGui import QMatrix4x4
        xform = getattr(group, "xform", None)
        if xform is None or xform == QMatrix4x4():
            return
        for child in group.children:
            child.xform = xform * (child.xform if child.xform is not None
                                   else QMatrix4x4())
        # An exploded view's offsets live in the container's frame, which
        # has just become the world's.
        from core.explode import rotate_offsets
        rotate_offsets(group, xform)
        if group.mesh.vertices:
            from core.group import transformed_mesh
            group.mesh = transformed_mesh(group.mesh, xform)
        group.xform = QMatrix4x4()

    def end_one_group_edit(self) -> None:
        """Leave the INNERMOST group only — Esc, which steps out
        one level and leaves you inside the parent."""
        self._leave_level()

    def end_group_edit(self) -> None:
        """Leave every open group-edit context, back to the loose mesh. The
        contract the whole app relies on before saving, exporting or
        switching documents: when this returns, nothing is open."""
        while self._edit_stack:
            self._leave_level()

    def _leave_level(self) -> None:
        if not self._edit_stack:
            return
        nivel = self._edit_stack.pop()
        share = nivel["share"]
        nivel["share"] = None
        self._edit_share = None
        if share is not None:
            # Headless callers (tests, the AI bridge): share back directly.
            # The viewport takes the share first and wraps it in a command.
            group, proto, xform, state0 = share
            if group.mesh.capture_state() == state0:
                self.restore_sharing(group, proto, xform)
            else:
                self.share_back(group, proto, xform, group.mesh)
        self.mesh = nivel["mesh"]
        self.edit_group = (self._edit_stack[-1]["group"] if self._edit_stack
                           else None)
        if not self._edit_stack:
            self._loose_mesh = None
        self.selection.clear()
        self.version += 1

    def take_edit_share(self):
        """The pending instance share-back ``(group, proto, xform, state0)``
        of the INNERMOST open group — handed over ONCE, so whoever ends the
        edit decides how (the viewport wraps it in an undoable command).

        It belongs to its level, not to the scene: taking it has to disarm
        that level too, or leaving would share the same edit back twice.
        """
        if self._edit_stack:
            share = self._edit_stack[-1]["share"]
            self._edit_stack[-1]["share"] = None
            self._edit_share = None
            return share
        share = self._edit_share
        self._edit_share = None
        return share

    @staticmethod
    def restore_sharing(group, proto, xform) -> None:
        """The instance left untouched: back on the shared definition."""
        group.mesh = proto
        group.xform = xform

    @staticmethod
    def share_back(group, proto, xform, edited) -> None:
        """Write the edited world-space mesh into the shared prototype (local
        coordinates) and put the instance back on it: every sibling shows
        the edit."""
        from core.group import transformed_mesh
        inverse, ok = xform.inverted()
        local = transformed_mesh(edited, inverse if ok else xform)
        proto.restore_state(local.capture_state())
        group.mesh = proto
        group.xform = xform

    @property
    def drawing_frame(self):
        """The axes drawing happens on (issue #44): the world's (``None``)
        at the top level, the open group's own axes inside it — a world
        matrix whose columns are red, green, blue and whose translation is
        the origin. Read by :mod:`core.axes`."""
        if self._edit_stack:
            return self._edit_stack[-1].get("frame")
        return None

    @property
    def loose_mesh(self):
        """The real loose mesh regardless of the edit context."""
        return self._loose_mesh if self.edit_group is not None else self.mesh

    # ---- Render views (loose + every group) ---------------------------------
    def placements(self):
        """Every visible placement in the scene: each group and, below it,
        the nested ones a component keeps inside itself, as
        ``(group, world_matrix_or_None)``.

        Face-me billboards are left out (they are drawn per frame, not from
        their mesh). Consumers that used to walk ``self.groups`` and read
        ``g.mesh`` want this — otherwise the geometry a component places
        inside itself is simply invisible to them."""
        from core.group import iter_placements
        for g in self.groups:
            if not self.entity_visible(g) or getattr(g, "billboard", False):
                continue
            for pg, m in iter_placements(g):
                if pg is not g and (getattr(pg, "billboard", False)
                                    or not self.entity_visible(pg)):
                    continue
                yield pg, m

    def render_edges(self):
        for e in self.loose_mesh.edges:
            if self.entity_visible(e):
                yield e
        for g, _m in self.placements():
            yield from g.mesh.edges

    def render_faces(self):
        for f in self.loose_mesh.faces:
            if self.entity_visible(f):
                yield f
        for g, _m in self.placements():
            yield from g.mesh.faces

    # ---- Mutations ----------------------------------------------------------
    def add_edge(self, a: QVector3D, b: QVector3D) -> Edge:
        edge = self.mesh.add_edge(a, b)
        self.version += 1
        return edge

    def select(self, edges: Iterable, additive: bool = False,
               mode: str | None = None) -> None:
        """Put *edges* (any entities) into the selection the way *mode*
        says — the usual click modifiers: ``"replace"`` (a plain click),
        ``"add"`` (Ctrl), ``"toggle"`` (Shift: what is in goes out, what is
        out comes in) and ``"remove"`` (Shift+Ctrl). ``additive=True`` is
        the old spelling of ``"add"`` and still works; an explicit *mode*
        wins over it."""
        mode = mode or ("add" if additive else "replace")
        if mode == "replace":
            self.selection.clear()
        if mode == "toggle":
            for ent in edges:
                if ent in self.selection:
                    self.selection.discard(ent)
                else:
                    self.selection.add(ent)
        elif mode == "remove":
            self.selection.difference_update(edges)
        else:
            self.selection.update(edges)
        self.bump_view()

    def clear_selection(self) -> None:
        if self.selection:
            self.selection.clear()
            self.bump_view()

    def bump_view(self) -> None:
        """A change of what is shown, not of the document (the selection):
        the caches keyed on ``version`` refresh, the document stays clean."""
        self.version += 1
        self.view_version += 1

    @property
    def content_version(self) -> int:
        """``version`` minus the view-only bumps: what "unsaved changes"
        compares against the version that was saved."""
        return self.version - self.view_version

    def invert_selection(self) -> int:
        """Edit ▸ Invert Selection (Ctrl+Shift+I): select every
        entity of the open context that is NOT selected now, and drop what
        is. The universe is Select All's — the loose edges and faces, the
        context's groups (the model's, or the open group's children) and the
        dimensions — minus what a click or a box could not pick either:
        hidden objects and faces, hidden or locked layers, and hidden edges
        (a smoothed surface's inner edges) while the hidden-geometry view is
        off. Returns the size of the new selection."""
        ctx = self.edit_group
        groups = self.groups if ctx is None else (getattr(ctx, "children", None) or [])
        show_hidden = bool(self.show_hidden_geometry)
        universe = [e for e in self.edges
                    if self.entity_selectable(e)
                    and (show_hidden or not getattr(e, "hidden", False))]
        universe += [f for f in self.faces if self.entity_selectable(f)]
        universe += [g for g in groups if self.entity_selectable(g)]
        universe += [d for d in self.dimensions if self.entity_selectable(d)]
        new = [ent for ent in universe if ent not in self.selection]
        self.selection.clear()
        self.selection.update(new)
        self.bump_view()             # the GL colour caches are keyed on it
        return len(new)

    def delete_selection(self) -> None:
        if not self.selection:
            return
        for ent in list(self.selection):
            if isinstance(ent, Edge):
                self.mesh.remove_edge(ent)
            elif isinstance(ent, Face):
                self.mesh.remove_face(ent)
        self.selection.clear()
        self.version += 1

    def clear(self) -> None:
        self.end_group_edit()
        if (self.mesh.edges or self.mesh.faces or self.selection
                or self.groups or self.dimensions or self.georef
                or self.tile_layer or self.geo_paths or self.terrain
                or self.guides or self.geo_points or self.text_labels
                or self.saved_views or self.compositions
                or self.image_planes or self.plugin_data):
            self.mesh.clear()
            self.groups.clear()
            self.dimensions.clear()
            self.text_labels.clear()
            self.geo_paths.clear()
            self.geo_points.clear()
            self.guides.clear()
            self.image_planes.clear()
            self.saved_views.clear()
            self.compositions.clear()
            self.custom_scales.clear()
            self.plugin_data = {}
            self.selection.clear()
            from core.layers import DEFAULT_LAYER, Layer
            self.layers = [Layer(DEFAULT_LAYER)]
            self.georef = None
            self.tile_layer = None
            self.terrain = None
            self.back_face_color = None
            self.active_ifc = None
            self.display_style = _make_style()
            self.shadows = _make_shadows()
            self.section_planes.clear()
            self.show_section_planes = True
            self.show_section_cuts = True
            self.show_hidden_objects = False
            self.show_hidden_geometry = False
            self.version += 1
        # Outside the guard: an empty document has a camera to forget too.
        self.camera_home = None
        self.units = {"length": "m", "precision": 2}
        self.plugin_data = {}

    # ---- Queries ------------------------------------------------------------
    def iter_world_faces(self):
        """Every visible face with the matrix that maps it to WORLD space:
        ``(face, matrix_or_None)``. Instance groups share a prototype mesh in
        local coordinates — exporters and geometry consumers must apply the
        matrix; classic faces come with ``None``."""
        for f in self.loose_mesh.faces:
            if self.entity_visible(f):
                yield f, None
        for g, m in self.placements():
            for f in g.mesh.faces:
                yield f, m

    def selection_bounds(self) -> tuple[QVector3D, QVector3D] | tuple[None, None]:
        """Axis-aligned bounding box of the SELECTION — what Zoom Selection
        frames, as ``bounds()`` is what Zoom Extents frames. ``(None, None)``
        when nothing selected has a place in space.

        Loose edges and faces, whole groups (nested placements included,
        vectorized per mesh like ``bounds()``), dimensions and reference
        images. Not cached: it runs once per command, over the selection
        only."""
        import numpy as np
        from core.group import iter_placements
        pts: list = []

        def add(p: QVector3D) -> None:
            pts.append((p.x(), p.y(), p.z()))

        for ent in self.selection:
            if hasattr(ent, "mesh"):          # Group / component instance
                for g, m in iter_placements(ent):
                    verts = g.mesh.vertices
                    if not verts:
                        continue
                    arr = np.array([[v.position.x(), v.position.y(),
                                     v.position.z()] for v in verts])
                    if m is not None:
                        d = m.data()          # column-major
                        rot = np.array([[d[0], d[4], d[8]],
                                        [d[1], d[5], d[9]],
                                        [d[2], d[6], d[10]]])
                        arr = arr @ rot.T + np.array([d[12], d[13], d[14]])
                    pts.append(tuple(arr.min(axis=0)))
                    pts.append(tuple(arr.max(axis=0)))
            elif hasattr(ent, "vertices"):    # Face
                for v in ent.vertices:
                    add(v)
            elif hasattr(ent, "corners"):     # ImagePlane
                for c in ent.corners():
                    add(c)
            elif hasattr(ent, "a") and hasattr(ent, "b"):    # Edge, Dimension
                add(ent.a)
                add(ent.b)
        if not pts:
            return None, None
        arr = np.array(pts, dtype=float)
        lo, hi = arr.min(axis=0), arr.max(axis=0)
        return QVector3D(*lo), QVector3D(*hi)

    def bounds(self) -> tuple[QVector3D, QVector3D] | tuple[None, None]:
        """Axis-aligned bounding box of all geometry. ``(None, None)`` if empty.

        CACHED per ``version`` — hovering over empty space derives the work
        plane (and the status-bar coordinate) from the model centre, so this
        runs on EVERY mouse move across sky or base map. The old per-corner
        Python walk cost ~1.7 s per call against piscina's 230k-face merged
        group, twice per hover: the event loop starved and GNOME declared
        the app dead (the paste "no responde" hang). Every mutation —
        commands, layer toggles — bumps ``version``, the same invariant the
        viewport's chunk caches key on.

        Group bounds are vectorized over each mesh's welded vertex list
        (as the instance branch always was), so an orphaned vertex left by
        a deletion may pad them slightly until the weld reuses it; loose
        entities keep the exact per-entity visibility walk."""
        cached = getattr(self, "_bounds_cache", None)
        if cached is not None and cached[0] == self.version:
            lo, hi = cached[1]
            if lo is None:
                return None, None
            return QVector3D(*lo), QVector3D(*hi)
        import numpy as np
        inf = float("inf")
        minx = miny = minz = inf
        maxx = maxy = maxz = -inf
        seen = False

        def absorb(v: QVector3D) -> None:
            nonlocal minx, miny, minz, maxx, maxy, maxz, seen
            seen = True
            x, y, z = v.x(), v.y(), v.z()
            if x < minx: minx = x
            if y < miny: miny = y
            if z < minz: minz = z
            if x > maxx: maxx = x
            if y > maxy: maxy = y
            if z > maxz: maxz = z

        for edge in self.loose_mesh.edges:
            if self.entity_visible(edge):
                absorb(edge.a)
                absorb(edge.b)
        for face in self.loose_mesh.faces:
            if self.entity_visible(face):
                for v in face.vertices:
                    absorb(v)
        # One vertex array per MESH, not per placement: a model of 21 406
        # placements over 2 722 meshes read 14 million vertices one by one
        # to learn its box, ~7 s (issue #158).
        per_mesh: dict = {}
        for g, m in self.placements():
            verts = g.mesh.vertices
            if not verts:
                continue
            key = id(g.mesh)
            arr = per_mesh.get(key)
            if arr is None:
                arr = per_mesh[key] = np.array(
                    [[v.position.x(), v.position.y(), v.position.z()]
                     for v in verts])
            if m is not None:
                d = m.data()          # column-major
                rot = np.array([[d[0], d[4], d[8]],
                                [d[1], d[5], d[9]],
                                [d[2], d[6], d[10]]])
                arr = arr @ rot.T + np.array([d[12], d[13], d[14]])
            glo, ghi = arr.min(axis=0), arr.max(axis=0)
            seen = True
            minx = min(minx, glo[0]); miny = min(miny, glo[1])
            minz = min(minz, glo[2])
            maxx = max(maxx, ghi[0]); maxy = max(maxy, ghi[1])
            maxz = max(maxz, ghi[2])
        if not seen:
            self._bounds_cache = (self.version, (None, None))
            return None, None
        self._bounds_cache = (self.version, ((minx, miny, minz),
                                             (maxx, maxy, maxz)))
        return QVector3D(minx, miny, minz), QVector3D(maxx, maxy, maxz)
