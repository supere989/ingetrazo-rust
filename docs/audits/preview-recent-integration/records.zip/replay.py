import hashlib,json,os,subprocess,time,zipfile
from pathlib import Path
repo=Path('/tmp/ingetrazo-next-integration')
out=Path(__file__).resolve().parent
bin=Path('/tmp/ingetrazo-native-font-merge-target/debug/examples')
python=Path('/tmp/ingetrazo-parity-python/bin/python')
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',INGETRAZO_STATE_DIR=str(out/'state'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'),XDG_CACHE_HOME=str(out/'cache'))
pin='6be29fe437a7cd992d4e079f71720821b25216b9'
assert subprocess.check_output(['git','-C','/work/ingetrazo','rev-parse','HEAD'],text=True).strip()==pin
assert not subprocess.check_output(['git','-C','/work/ingetrazo','status','--porcelain'],text=True).strip()
archives={}
def extract(name,selected,target):
 p=repo/'docs/audits'/name;m=json.loads((p/'manifest.json').read_text());raw=(p/'records.zip').read_bytes();sha=hashlib.sha256(raw).hexdigest()
 assert sha==m['archive_sha256'],name
 records=m.get('members',m.get('entries',m.get('records')))
 if isinstance(records,list):
  rows=records;records={r['path']:r for r in rows};assert len(rows)==len(records)
 with zipfile.ZipFile(p/'records.zip')as z:
  assert set(z.namelist())==set(records)
  for key,row in records.items():
   b=z.read(key);assert hashlib.sha256(b).hexdigest()==(row if isinstance(row,str)else row['sha256']),key
   if isinstance(row,dict):assert len(b)==row['bytes'],key
   if key in selected:
    dest=target/selected[key];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  assert set(selected)<=set(records)
 archives[name]=sha

def run(cmd,path):
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w')as f:subprocess.run(list(map(str,cmd)),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120,check=True)

preview=out/'preview';cases=['front-z','side-x','aligned','axial-x','axial-y','nested']
names=[c+x for c in cases for x in ['-input.igz','-original.igz']]+['preview-original.json','initial-native.json']
extract('dimension-preview',{n:n for n in names},preview)
anchors=out/'anchors';cases=['near','outside','nested-shared','billboard','orphan']
names=[c+x for c in cases for x in ['-input.igz','-original.igz']]+['admission-original.json','first-native-inverse-mismatch.json']
extract('dimension-anchor-admission',{n:n for n in names},anchors)
share=out/'shareback';prefix='selective-linux/shareback-annotations-ci/'
extract('native-platform/aff228da',{prefix+'original.json':'original.json',prefix+'old-snapshot/native.json':'old-snapshot/native.json',prefix+'native/native.json':'aff-failure.json'},share)
recent=out/'recent';extract('open-recent',{'original-recent.json':'original-recent.json'},recent)
start=time.monotonic()
run([bin/'dimension_anchor_acceptance_fixture',preview,'--preview'],'preview/runtime.log')
run([python,repo/'scripts/check-dimension-preview.py',preview],'preview/acceptance.json')
run([python,repo/'scripts/reopen-dimension-preview.py',preview],'preview/reopen-acceptance.json')
run([bin/'dimension_anchor_acceptance_fixture',anchors,'--admission'],'anchors/runtime.log')
run([python,repo/'scripts/check-dimension-anchor-admission.py',anchors],'anchors/acceptance.json')
run([python,repo/'scripts/reopen-dimension-anchor-admission.py',anchors],'anchors/reopen-acceptance.json')
run([bin/'shareback_annotation_fixture',share/'native'],'shareback/runtime.log')
run([python,repo/'scripts/check-shareback-annotations.py',share],'shareback/acceptance.json')
source=json.loads((share/'original.json').read_text())['cases'];old=json.loads((share/'aff-failure.json').read_text())['cases']
differences=[]
def diff(a,b,path=''):
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  assert len(a)==len(b)
  for i,(x,y)in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:differences.append(dict(path=path,source=a,aff=b))
diff(source,old)
assert differences==[{'path':'/finish/dimensions/1/anchor_b','source':True,'aff':False},{'path':'/nested_parked_and_root/0/dimensions/1/anchor_b','source':True,'aff':False}],differences
(share/'retained-failure-rejection.json').write_text(json.dumps(dict(rejected=True,differences=differences),indent=2)+'\n')
run([bin/'context_document_lifecycle',recent,'--recent'],'recent/runtime.log')
run([python,repo/'scripts/check-open-recent.py',recent],'recent/acceptance.json')
(out/'replay-core.json').write_text(json.dumps(dict(seconds=time.monotonic()-start,archives=archives,fresh_source_acquisitions=0),indent=2)+'\n')
print((out/'replay-core.json').read_text())
