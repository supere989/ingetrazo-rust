import os,sys,json,time,ctypes,hashlib,subprocess
from pathlib import Path
root=Path('/work/ingetrazo');sys.path.insert(0,str(root))
from PySide6.QtWidgets import QApplication
from views.main_window import MainWindow
app=QApplication([]);host=MainWindow();host.show();v=host.viewport
for _ in range(120):app.processEvents();v.update();time.sleep(.005)
assert v.context().isValid() and v._scene_fbo.isValid()
v.makeCurrent();gl=ctypes.CDLL('libGL.so.1')
gl.glGetString.argtypes=[ctypes.c_uint];gl.glGetString.restype=ctypes.c_char_p
gl.glGetIntegerv.argtypes=[ctypes.c_uint,ctypes.POINTER(ctypes.c_int)]
gl.glGetFloatv.argtypes=[ctypes.c_uint,ctypes.POINTER(ctypes.c_float)]
gl.glIsEnabled.argtypes=[ctypes.c_uint];gl.glIsEnabled.restype=ctypes.c_ubyte
gl.glGetMultisamplefv.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.POINTER(ctypes.c_float)]
gl.glBindFramebuffer.argtypes=[ctypes.c_uint,ctypes.c_uint]
def integers(key,n=1):
 values=(ctypes.c_int*n)();gl.glGetIntegerv(key,values);return list(values)
old=integers(0x8CA6)[0];assert v._scene_fbo.bind()
count=integers(0x80A9)[0];positions=[]
for index in range(count):
 value=(ctypes.c_float*2)();gl.glGetMultisamplefv(0x8E50,index,value);positions.append(list(value))
width=ctypes.c_float();gl.glGetFloatv(0x0B21,ctypes.byref(width))
result={'source_pin':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'scope':'Read-only actual bound scene-FBO sample query, no screenshot or source corpus recapture','driver':{k:gl.glGetString(c).decode()for k,c in [('vendor',0x1F00),('renderer',0x1F01),('version',0x1F02)]},'source_requested_samples':v._msaa,'qt_fbo_samples':v._scene_fbo.format().samples(),'actual_gl_samples':count,'sample_buffers':integers(0x80A8)[0],'sample_positions':positions,'viewport':integers(0x0BA2,4),'line_width':width.value,'multisample_enabled':bool(gl.glIsEnabled(0x809D)),'line_smooth_enabled':bool(gl.glIsEnabled(0x0B20))}
gl.glBindFramebuffer(0x8D40,old);v.doneCurrent();host.hide();print(json.dumps(result,indent=2))
Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
