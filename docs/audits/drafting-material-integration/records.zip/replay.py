from pathlib import Path
import ast, hashlib, json, os, subprocess, sys, time, zipfile
from concurrent.futures import ThreadPoolExecutor
repo=Path('/tmp/ingetrazo-next-integration');out=Path('/tmp/ingetrazo-drafting-material-integration');binaries=Path('/tmp/ingetrazo-native-font-merge-target/debug/examples')
sys.path.insert(0,str(repo/'scripts'));from consumer_stages import Stages
stages=Stages(out);text=(repo/'scripts/check-document-axes-integration.py').read_text();tree=ast.parse(text)
consumers=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='consumers' for t in n.targets))
functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['_archive','archive','run']],type_ignores=[])
used=['shape_drafting_workflows','freehand_workflows','context_document_lifecycle','drafting_acceptance_fixture','dae_import_acceptance_fixture']
identities={n:stages.stage('binary:'+n,[],lambda n=n:hashlib.sha256((binaries/n).read_bytes()).hexdigest()) for n in used}
def lane(pair):
    name,code=pair
    env=dict(os.environ,QT_QPA_PLATFORM='offscreen',INGETRAZO_STATE_DIR=str(out/'state'/name),XDG_CONFIG_HOME=str(out/'config'/name),XDG_DATA_HOME=str(out/'data'/name),XDG_CACHE_HOME=str(out/'cache'/name))
    ns=dict(repo=repo,binaries=binaries,out=out,stages=stages,archive_dependencies={},consumers=consumers,suffix='',env=env,Path=Path,hashlib=hashlib,json=json,zipfile=zipfile,subprocess=subprocess,sys=sys)
    exec(compile(functions,'actual-ci-stage-functions','exec'),ns)
    exec(compile(code,'actual-ci-selected-'+name,'exec'),ns)
def block(start,end):return text[text.index(start):text.index(end)]
lanes=[
 ('shape',block('shape = out/','freehand = out/')),
 ('freehand',block('freehand = out/','def summarize():')),
 ('obj-mtl',block('obj_mtl = out/','nested_import = out/')),
 ('nested',block('nested_import = out/','appearance = out/')),
 ('import-preferences',block('import_preferences = out/','obj_mtl = out/')),
 ('dae',"run([sys.executable, repo/'scripts/replay-dae-material-resolution.py', binaries/'dae_import_acceptance_fixture', out/'dae-materials'], 'dae-materials/runtime.log', requires=['binary:dae_import_acceptance_fixture'])"),
 ('drafting',"""
inputs=[row['input'] for row in json.loads((repo/'docs/audits/drafting-accepted-corpus.json').read_text())]
(out/'drafting-input.json').write_text(json.dumps(inputs))
run([binaries/'drafting_acceptance_fixture', out/'drafting-input.json', out/'drafting-native.json'],'drafting-runtime.log')
run([sys.executable, repo/'scripts/check-retained-drafting.py',repo/'docs/audits/drafting-accepted-corpus.json',out/'drafting-native.json',out/'drafting-check.json'],'drafting-checker.log',requires=['drafting-runtime.log'])
""")]
started=time.perf_counter()
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,lanes))
seconds=time.perf_counter()-started
summary=lambda:{'result':'pass','seconds':seconds,'max_concurrent_processes':2,'fresh_source_acquisitions':0,'lanes':[name for name,_ in lanes],'binaries':identities,'asserted_runtime':json.loads((out/'provenance.json').read_text())['runtime_revision']}
raise SystemExit(stages.finish(summary))
