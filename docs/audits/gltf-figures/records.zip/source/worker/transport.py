import json,subprocess,time,select
from pathlib import Path
root='/home/raymondj/.local/share/containers/storage/overlay/73bdc7afba223e983c173af5f2e8792d8f11e0f7f2b72103b534260022eaadb6/merged';proof='/tmp/ingetrazo-gltf-figures-proof';receipts=[]
for engine in ['cycles','eevee']:
 work=proof+'/worker/'+engine
 cmd=['podman','run','-i','--rm','--read-only','--network','none','--userns','keep-id:uid=1000,gid=1000','--user','1000:1000','--security-opt','label=disable','--tmpfs','/tmp:rw','-v','/usr:/usr:ro','-v','/opt/intel:/opt/intel:ro','-v',root+proof+':'+proof+':rw','-e','LD_LIBRARY_PATH=/usr/lib:/opt/intel/oneapi/compiler/latest/lib:/usr/lib/pulseaudio','-e','XDG_CACHE_HOME=/tmp/blender-cache','-e','XDG_CONFIG_HOME=/tmp/blender-config','-e','LIBGL_ALWAYS_SOFTWARE=1','--entrypoint','/usr/bin/blender','a6597584287dfce8099218b3231240c1a939d73a573eeb260933f0d2b9b7070c','-t','2','-b','--factory-startup','--python',work+'/render_scene.py','--',work+'/job.json']
 requests=json.loads(subprocess.check_output(['podman','exec','ingetrazo-publish','cat',work+'/requests.json']))
 start=time.monotonic();proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=[]
 def until(marker):
  deadline=time.monotonic()+90
  while True:
   if time.monotonic()>deadline:proc.kill();raise TimeoutError(marker)
   ready,_,_=select.select([proc.stdout],[],[],1)
   if not ready:continue
   line=proc.stdout.readline();raw.append(line)
   if not line:raise RuntimeError('worker exited')
   if marker.encode() in line:return
 try:
  until('INGETRAZO ready')
  for req in requests:
   proc.stdin.write((json.dumps(req)+'\n').encode());proc.stdin.flush();until('INGETRAZO done '+req['output'])
  proc.stdin.write(b'{"quit":true}\n');proc.stdin.flush();proc.stdin.close();raw.append(proc.stdout.read());exit=proc.wait(timeout=30)
 finally:Path('/tmp/gltf-figures-source-'+engine+'.log').write_bytes(b''.join(raw))
 receipts.append(dict(engine=engine,command=cmd,seconds=time.monotonic()-start,exit=exit,requests=len(requests),single_worker=True));print(engine,exit)
Path('/tmp/gltf-figures-source-transport.json').write_text(json.dumps(receipts,indent=2))
