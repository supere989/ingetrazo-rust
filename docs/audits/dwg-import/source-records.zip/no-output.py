import sys;sys.stderr.write('first\nsecond\nthird\nfourth\n');sys.exit(3)
