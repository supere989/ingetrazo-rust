from pathlib import Path;import sys;Path(sys.argv[1]).write_bytes(b'0\nEOF');sys.stderr.buffer.write(b'CA\xd1ERIAS\n');sys.exit(7)
